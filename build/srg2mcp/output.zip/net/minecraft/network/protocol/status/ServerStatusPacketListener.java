package net.minecraft.network.protocol.status;

import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.protocol.game.ServerPacketListener;
import net.minecraft.network.protocol.game.ServerPingPacketListener;

public interface ServerStatusPacketListener extends ServerPacketListener, ServerPingPacketListener {
   default ConnectionProtocol protocol() {
      return ConnectionProtocol.STATUS;
   }

   void handleStatusRequest(ServerboundStatusRequestPacket p_134987_);
}