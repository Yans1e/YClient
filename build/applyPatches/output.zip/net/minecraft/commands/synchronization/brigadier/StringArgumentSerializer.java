package net.minecraft.commands.synchronization.brigadier;

import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.synchronization.ArgumentTypeInfo;
import net.minecraft.network.FriendlyByteBuf;

public class StringArgumentSerializer implements ArgumentTypeInfo<StringArgumentType, StringArgumentSerializer.Template> {
   public void m_214155_(StringArgumentSerializer.Template p_235616_, FriendlyByteBuf p_235617_) {
      p_235617_.m_130068_(p_235616_.f_235623_);
   }

   public StringArgumentSerializer.Template m_213618_(FriendlyByteBuf p_235619_) {
      StringArgumentType.StringType stringtype = p_235619_.m_130066_(StringArgumentType.StringType.class);
      return new StringArgumentSerializer.Template(stringtype);
   }

   public void m_213719_(StringArgumentSerializer.Template p_235613_, JsonObject p_235614_) {
      String s;
      switch (p_235613_.f_235623_) {
         case SINGLE_WORD:
            s = "word";
            break;
         case QUOTABLE_PHRASE:
            s = "phrase";
            break;
         case GREEDY_PHRASE:
            s = "greedy";
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      p_235614_.addProperty("type", s);
   }

   public StringArgumentSerializer.Template m_214163_(StringArgumentType p_235605_) {
      return new StringArgumentSerializer.Template(p_235605_.getType());
   }

   public final class Template implements ArgumentTypeInfo.Template<StringArgumentType> {
      final StringArgumentType.StringType f_235623_;

      public Template(StringArgumentType.StringType p_235626_) {
         this.f_235623_ = p_235626_;
      }

      public StringArgumentType m_213879_(CommandBuildContext p_235629_) {
         StringArgumentType stringargumenttype;
         switch (this.f_235623_) {
            case SINGLE_WORD:
               stringargumenttype = StringArgumentType.word();
               break;
            case QUOTABLE_PHRASE:
               stringargumenttype = StringArgumentType.string();
               break;
            case GREEDY_PHRASE:
               stringargumenttype = StringArgumentType.greedyString();
               break;
            default:
               throw new IncompatibleClassChangeError();
         }

         return stringargumenttype;
      }

      public ArgumentTypeInfo<StringArgumentType, ?> m_213709_() {
         return StringArgumentSerializer.this;
      }
   }
}