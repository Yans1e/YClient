package net.minecraft.commands;

import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.network.chat.PlayerChatMessage;

public interface CommandSigningContext {
   CommandSigningContext f_242494_ = new CommandSigningContext() {
      @Nullable
      public PlayerChatMessage m_213987_(String p_242898_) {
         return null;
      }
   };

   @Nullable
   PlayerChatMessage m_213987_(String p_230580_);

   public static record SignedArguments(Map<String, PlayerChatMessage> f_242498_) implements CommandSigningContext {
      @Nullable
      public PlayerChatMessage m_213987_(String p_242852_) {
         return this.f_242498_.get(p_242852_);
      }
   }
}