package net.minecraft.core.particles;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;

public record SculkChargeParticleOptions(float f_235914_) implements ParticleOptions {
   public static final Codec<SculkChargeParticleOptions> f_235912_ = RecordCodecBuilder.create((p_235920_) -> {
      return p_235920_.group(Codec.FLOAT.fieldOf("roll").forGetter((p_235922_) -> {
         return p_235922_.f_235914_;
      })).apply(p_235920_, SculkChargeParticleOptions::new);
   });
   public static final ParticleOptions.Deserializer<SculkChargeParticleOptions> f_235913_ = new ParticleOptions.Deserializer<SculkChargeParticleOptions>() {
      public SculkChargeParticleOptions m_5739_(ParticleType<SculkChargeParticleOptions> p_235933_, StringReader p_235934_) throws CommandSyntaxException {
         p_235934_.expect(' ');
         float f = p_235934_.readFloat();
         return new SculkChargeParticleOptions(f);
      }

      public SculkChargeParticleOptions m_6507_(ParticleType<SculkChargeParticleOptions> p_235936_, FriendlyByteBuf p_235937_) {
         return new SculkChargeParticleOptions(p_235937_.readFloat());
      }
   };

   public ParticleType<SculkChargeParticleOptions> m_6012_() {
      return ParticleTypes.f_235899_;
   }

   public void m_7711_(FriendlyByteBuf p_235924_) {
      p_235924_.writeFloat(this.f_235914_);
   }

   public String m_5942_() {
      return String.format(Locale.ROOT, "%s %.2f", BuiltInRegistries.f_257034_.m_7981_(this.m_6012_()), this.f_235914_);
   }
}