package net.minecraft.core;

public interface Position {
   double m_7096_();

   double m_7098_();

   double m_7094_();
}