package net.minecraft.network.protocol.common.custom;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

public record PoiAddedDebugPayload(BlockPos f_290840_, String f_291238_, int f_290692_) implements CustomPacketPayload {
   public static final ResourceLocation f_290556_ = new ResourceLocation("debug/poi_added");

   public PoiAddedDebugPayload(FriendlyByteBuf p_300736_) {
      this(p_300736_.m_130135_(), p_300736_.m_130277_(), p_300736_.readInt());
   }

   public void m_293110_(FriendlyByteBuf p_298137_) {
      p_298137_.m_130064_(this.f_290840_);
      p_298137_.m_130070_(this.f_291238_);
      p_298137_.writeInt(this.f_290692_);
   }

   public ResourceLocation m_292644_() {
      return f_290556_;
   }
}