package net.minecraft.network.protocol.common;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;
import net.minecraft.server.level.ClientInformation;

public record ServerboundClientInformationPacket(ClientInformation f_291402_) implements Packet<ServerCommonPacketListener> {
   public ServerboundClientInformationPacket(FriendlyByteBuf p_299808_) {
      this(new ClientInformation(p_299808_));
   }

   public void m_5779_(FriendlyByteBuf p_298054_) {
      this.f_291402_.m_293760_(p_298054_);
   }

   public void m_5797_(ServerCommonPacketListener p_300686_) {
      p_300686_.m_9844_(this);
   }
}