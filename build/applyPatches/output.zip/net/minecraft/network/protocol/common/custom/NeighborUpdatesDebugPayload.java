package net.minecraft.network.protocol.common.custom;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

public record NeighborUpdatesDebugPayload(long f_291308_, BlockPos f_290702_) implements CustomPacketPayload {
   public static final ResourceLocation f_291649_ = new ResourceLocation("debug/neighbors_update");

   public NeighborUpdatesDebugPayload(FriendlyByteBuf p_301219_) {
      this(p_301219_.m_130258_(), p_301219_.m_130135_());
   }

   public void m_293110_(FriendlyByteBuf p_300822_) {
      p_300822_.m_130103_(this.f_291308_);
      p_300822_.m_130064_(this.f_290702_);
   }

   public ResourceLocation m_292644_() {
      return f_291649_;
   }
}