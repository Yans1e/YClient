package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;
import net.minecraft.world.level.ChunkPos;

public record ClientboundForgetLevelChunkPacket(ChunkPos f_290761_) implements Packet<ClientGamePacketListener> {
   public ClientboundForgetLevelChunkPacket(FriendlyByteBuf p_178858_) {
      this(p_178858_.m_178383_());
   }

   public void m_5779_(FriendlyByteBuf p_132151_) {
      p_132151_.m_178341_(this.f_290761_);
   }

   public void m_5797_(ClientGamePacketListener p_132148_) {
      p_132148_.m_5729_(this);
   }
}