package net.minecraft.data.recipes;

import com.google.gson.JsonObject;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementRequirements;
import net.minecraft.advancements.AdvancementRewards;
import net.minecraft.advancements.Criterion;
import net.minecraft.advancements.critereon.RecipeUnlockedTrigger;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.ItemLike;

public class SingleItemRecipeBuilder implements RecipeBuilder {
   private final RecipeCategory f_244239_;
   private final Item f_126302_;
   private final Ingredient f_126303_;
   private final int f_126304_;
   private final Map<String, Criterion<?>> f_291531_ = new LinkedHashMap<>();
   @Nullable
   private String f_126306_;
   private final RecipeSerializer<?> f_126307_;

   public SingleItemRecipeBuilder(RecipeCategory p_251425_, RecipeSerializer<?> p_249762_, Ingredient p_251221_, ItemLike p_251302_, int p_250964_) {
      this.f_244239_ = p_251425_;
      this.f_126307_ = p_249762_;
      this.f_126302_ = p_251302_.m_5456_();
      this.f_126303_ = p_251221_;
      this.f_126304_ = p_250964_;
   }

   public static SingleItemRecipeBuilder m_245264_(Ingredient p_248596_, RecipeCategory p_250503_, ItemLike p_250269_) {
      return new SingleItemRecipeBuilder(p_250503_, RecipeSerializer.f_44095_, p_248596_, p_250269_, 1);
   }

   public static SingleItemRecipeBuilder m_246944_(Ingredient p_251375_, RecipeCategory p_248984_, ItemLike p_250105_, int p_249506_) {
      return new SingleItemRecipeBuilder(p_248984_, RecipeSerializer.f_44095_, p_251375_, p_250105_, p_249506_);
   }

   public SingleItemRecipeBuilder m_126132_(String p_176810_, Criterion<?> p_298188_) {
      this.f_291531_.put(p_176810_, p_298188_);
      return this;
   }

   public SingleItemRecipeBuilder m_126145_(@Nullable String p_176808_) {
      this.f_126306_ = p_176808_;
      return this;
   }

   public Item m_142372_() {
      return this.f_126302_;
   }

   public void m_126140_(RecipeOutput p_298439_, ResourceLocation p_126328_) {
      this.m_126329_(p_126328_);
      Advancement.Builder advancement$builder = p_298439_.m_293552_().m_138383_("has_the_recipe", RecipeUnlockedTrigger.m_63728_(p_126328_)).m_138354_(AdvancementRewards.Builder.m_10009_(p_126328_)).m_138360_(AdvancementRequirements.Strategy.f_291456_);
      this.f_291531_.forEach(advancement$builder::m_138383_);
      p_298439_.m_292927_(new SingleItemRecipeBuilder.Result(p_126328_, this.f_126307_, this.f_126306_ == null ? "" : this.f_126306_, this.f_126303_, this.f_126302_, this.f_126304_, advancement$builder.m_138403_(p_126328_.m_246208_("recipes/" + this.f_244239_.m_247710_() + "/"))));
   }

   private void m_126329_(ResourceLocation p_126330_) {
      if (this.f_291531_.isEmpty()) {
         throw new IllegalStateException("No way of obtaining recipe " + p_126330_);
      }
   }

   public static record Result(ResourceLocation f_126331_, RecipeSerializer<?> f_126338_, String f_126332_, Ingredient f_126333_, Item f_126334_, int f_126335_, AdvancementHolder f_126336_) implements FinishedRecipe {
      public void m_7917_(JsonObject p_126349_) {
         if (!this.f_126332_.isEmpty()) {
            p_126349_.addProperty("group", this.f_126332_);
         }

         p_126349_.add("ingredient", this.f_126333_.m_43942_(false));
         p_126349_.addProperty("result", BuiltInRegistries.f_257033_.m_7981_(this.f_126334_).toString());
         p_126349_.addProperty("count", this.f_126335_);
      }

      public ResourceLocation m_126168_() {
         return this.f_126331_;
      }

      public RecipeSerializer<?> m_126169_() {
         return this.f_126338_;
      }

      public AdvancementHolder m_126373_() {
         return this.f_126336_;
      }
   }
}