package net.minecraft.data.advancements;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;

public class AdvancementProvider implements DataProvider {
   private final PackOutput.PathProvider f_236156_;
   private final List<AdvancementSubProvider> f_244266_;
   private final CompletableFuture<HolderLookup.Provider> f_254664_;

   public AdvancementProvider(PackOutput p_256529_, CompletableFuture<HolderLookup.Provider> p_255722_, List<AdvancementSubProvider> p_255883_) {
      this.f_236156_ = p_256529_.m_245269_(PackOutput.Target.DATA_PACK, "advancements");
      this.f_244266_ = p_255883_;
      this.f_254664_ = p_255722_;
   }

   public CompletableFuture<?> m_213708_(CachedOutput p_254268_) {
      return this.f_254664_.thenCompose((p_255484_) -> {
         Set<ResourceLocation> set = new HashSet<>();
         List<CompletableFuture<?>> list = new ArrayList<>();
         Consumer<AdvancementHolder> consumer = (p_296340_) -> {
            if (!set.add(p_296340_.f_291758_())) {
               throw new IllegalStateException("Duplicate advancement " + p_296340_.f_291758_());
            } else {
               Path path = this.f_236156_.m_245731_(p_296340_.f_291758_());
               list.add(DataProvider.m_253162_(p_254268_, p_296340_.f_290952_().m_294498_(), path));
            }
         };

         for(AdvancementSubProvider advancementsubprovider : this.f_244266_) {
            advancementsubprovider.m_245571_(p_255484_, consumer);
         }

         return CompletableFuture.allOf(list.toArray((p_253393_) -> {
            return new CompletableFuture[p_253393_];
         }));
      });
   }

   public final String m_6055_() {
      return "Advancements";
   }
}