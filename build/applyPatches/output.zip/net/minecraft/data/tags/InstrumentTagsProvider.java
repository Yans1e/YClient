package net.minecraft.data.tags;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.tags.InstrumentTags;
import net.minecraft.world.item.Instrument;
import net.minecraft.world.item.Instruments;

public class InstrumentTagsProvider extends TagsProvider<Instrument> {
   public InstrumentTagsProvider(PackOutput p_256418_, CompletableFuture<HolderLookup.Provider> p_256038_) {
      super(p_256418_, Registries.f_257010_, p_256038_);
   }

   protected void m_6577_(HolderLookup.Provider p_256291_) {
      this.m_206424_(InstrumentTags.f_215856_).m_255204_(Instruments.f_220139_).m_255204_(Instruments.f_220140_).m_255204_(Instruments.f_220141_).m_255204_(Instruments.f_220142_);
      this.m_206424_(InstrumentTags.f_215857_).m_255204_(Instruments.f_220143_).m_255204_(Instruments.f_220144_).m_255204_(Instruments.f_220145_).m_255204_(Instruments.f_220146_);
      this.m_206424_(InstrumentTags.f_215858_).m_206428_(InstrumentTags.f_215856_).m_206428_(InstrumentTags.f_215857_);
   }
}