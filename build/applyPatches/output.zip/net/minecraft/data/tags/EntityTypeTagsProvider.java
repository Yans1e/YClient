package net.minecraft.data.tags;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.EntityType;

public class EntityTypeTagsProvider extends IntrinsicHolderTagsProvider<EntityType<?>> {
   public EntityTypeTagsProvider(PackOutput p_256095_, CompletableFuture<HolderLookup.Provider> p_256572_) {
      super(p_256095_, Registries.f_256939_, p_256572_, (p_256665_) -> {
         return p_256665_.m_204041_().m_205785_();
      });
   }

   protected void m_6577_(HolderLookup.Provider p_255894_) {
      this.m_206424_(EntityTypeTags.f_13120_).m_255179_(EntityType.f_20524_, EntityType.f_20481_, EntityType.f_20497_);
      this.m_206424_(EntityTypeTags.f_13121_).m_255179_(EntityType.f_20568_, EntityType.f_20513_, EntityType.f_20518_, EntityType.f_20493_, EntityType.f_20459_, EntityType.f_20495_);
      this.m_206424_(EntityTypeTags.f_13122_).m_255245_(EntityType.f_20550_);
      this.m_206424_(EntityTypeTags.f_13123_).m_255179_(EntityType.f_20548_, EntityType.f_20478_);
      this.m_206424_(EntityTypeTags.f_13124_).m_206428_(EntityTypeTags.f_13123_).m_255179_(EntityType.f_20477_, EntityType.f_20463_, EntityType.f_20527_, EntityType.f_20483_, EntityType.f_20487_, EntityType.f_20561_, EntityType.f_20498_);
      this.m_206424_(EntityTypeTags.f_144291_).m_255179_(EntityType.f_20517_, EntityType.f_20567_, EntityType.f_20523_, EntityType.f_20452_);
      this.m_206424_(EntityTypeTags.f_144293_).m_255179_(EntityType.f_20489_, EntityType.f_20516_, EntityType.f_20519_, EntityType.f_20556_, EntityType.f_20480_, EntityType.f_147034_, EntityType.f_217013_);
      this.m_206424_(EntityTypeTags.f_144292_).m_255179_(EntityType.f_20562_, EntityType.f_20455_, EntityType.f_20563_);
      this.m_206424_(EntityTypeTags.f_144294_).m_255179_(EntityType.f_20481_, EntityType.f_20514_, EntityType.f_20528_, EntityType.f_20496_);
      this.m_206424_(EntityTypeTags.f_144295_).m_255179_(EntityType.f_20482_, EntityType.f_20551_, EntityType.f_20468_);
      this.m_206424_(EntityTypeTags.f_215847_).m_255179_(EntityType.f_20526_, EntityType.f_20468_);
      this.m_206424_(EntityTypeTags.f_273841_).m_255179_(EntityType.f_20460_, EntityType.f_20528_, EntityType.f_20521_, EntityType.f_217014_, EntityType.f_20549_, EntityType.f_20550_, EntityType.f_20551_, EntityType.f_20553_, EntityType.f_20555_, EntityType.f_20453_, EntityType.f_20509_, EntityType.f_20468_, EntityType.f_20505_, EntityType.f_20508_, EntityType.f_20496_);
      this.m_206424_(EntityTypeTags.f_275751_).m_255179_(EntityType.f_243976_, EntityType.f_20555_, EntityType.f_20560_, EntityType.f_20457_, EntityType.f_20466_, EntityType.f_20503_, EntityType.f_20510_, EntityType.f_20518_, EntityType.f_20479_, EntityType.f_20482_, EntityType.f_20488_, EntityType.f_20502_);
      this.m_206424_(EntityTypeTags.f_291187_).m_255179_(EntityType.f_20526_, EntityType.f_20468_);
   }
}