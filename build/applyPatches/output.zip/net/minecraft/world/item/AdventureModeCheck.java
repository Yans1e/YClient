package net.minecraft.world.item;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.commands.arguments.blocks.BlockPredicateArgument;
import net.minecraft.core.Registry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;

public class AdventureModeCheck {
   private final String f_186321_;
   @Nullable
   private BlockInWorld f_186322_;
   private boolean f_186323_;
   private boolean f_186324_;

   public AdventureModeCheck(String p_186327_) {
      this.f_186321_ = p_186327_;
   }

   private static boolean m_186332_(BlockInWorld p_186333_, @Nullable BlockInWorld p_186334_, boolean p_186335_) {
      if (p_186334_ != null && p_186333_.m_61168_() == p_186334_.m_61168_()) {
         if (!p_186335_) {
            return true;
         } else if (p_186333_.m_61174_() == null && p_186334_.m_61174_() == null) {
            return true;
         } else {
            return p_186333_.m_61174_() != null && p_186334_.m_61174_() != null ? Objects.equals(p_186333_.m_61174_().m_187481_(), p_186334_.m_61174_().m_187481_()) : false;
         }
      } else {
         return false;
      }
   }

   public boolean m_204085_(ItemStack p_204086_, Registry<Block> p_204087_, BlockInWorld p_204088_) {
      if (m_186332_(p_204088_, this.f_186322_, this.f_186324_)) {
         return this.f_186323_;
      } else {
         this.f_186322_ = p_204088_;
         this.f_186324_ = false;
         CompoundTag compoundtag = p_204086_.m_41783_();
         if (compoundtag != null && compoundtag.m_128425_(this.f_186321_, 9)) {
            ListTag listtag = compoundtag.m_128437_(this.f_186321_, 8);

            for(int i = 0; i < listtag.size(); ++i) {
               String s = listtag.m_128778_(i);

               try {
                  BlockPredicateArgument.Result blockpredicateargument$result = BlockPredicateArgument.m_234633_(p_204087_.m_255303_(), new StringReader(s));
                  this.f_186324_ |= blockpredicateargument$result.m_183631_();
                  if (blockpredicateargument$result.test(p_204088_)) {
                     this.f_186323_ = true;
                     return true;
                  }
               } catch (CommandSyntaxException commandsyntaxexception) {
               }
            }
         }

         this.f_186323_ = false;
         return false;
      }
   }
}