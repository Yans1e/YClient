package net.minecraft.world.item;

import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.level.ItemLike;

public class CreativeModeTab {
   private final Component f_40764_;
   String f_40766_ = "items.png";
   boolean f_40767_ = true;
   boolean f_40768_ = true;
   boolean f_257018_ = false;
   private final CreativeModeTab.Row f_256931_;
   private final int f_256967_;
   private final CreativeModeTab.Type f_256819_;
   @Nullable
   private ItemStack f_40770_;
   private Collection<ItemStack> f_243839_ = ItemStackLinkedSet.m_261170_();
   private Set<ItemStack> f_243841_ = ItemStackLinkedSet.m_261170_();
   @Nullable
   private Consumer<List<ItemStack>> f_256965_;
   private final Supplier<ItemStack> f_256912_;
   private final CreativeModeTab.DisplayItemsGenerator f_256824_;

   CreativeModeTab(CreativeModeTab.Row p_260217_, int p_259557_, CreativeModeTab.Type p_260176_, Component p_260100_, Supplier<ItemStack> p_259543_, CreativeModeTab.DisplayItemsGenerator p_259085_) {
      this.f_256931_ = p_260217_;
      this.f_256967_ = p_259557_;
      this.f_40764_ = p_260100_;
      this.f_256912_ = p_259543_;
      this.f_256824_ = p_259085_;
      this.f_256819_ = p_260176_;
   }

   public static CreativeModeTab.Builder m_257815_(CreativeModeTab.Row p_259342_, int p_260312_) {
      return new CreativeModeTab.Builder(p_259342_, p_260312_);
   }

   public Component m_40786_() {
      return this.f_40764_;
   }

   public ItemStack m_40787_() {
      if (this.f_40770_ == null) {
         this.f_40770_ = this.f_256912_.get();
      }

      return this.f_40770_;
   }

   public String m_40788_() {
      return this.f_40766_;
   }

   public boolean m_40789_() {
      return this.f_40768_;
   }

   public boolean m_40791_() {
      return this.f_40767_;
   }

   public int m_257903_() {
      return this.f_256967_;
   }

   public CreativeModeTab.Row m_258064_() {
      return this.f_256931_;
   }

   public boolean m_257905_() {
      return !this.f_243839_.isEmpty();
   }

   public boolean m_257497_() {
      return this.f_256819_ != CreativeModeTab.Type.CATEGORY || this.m_257905_();
   }

   public boolean m_6563_() {
      return this.f_257018_;
   }

   public CreativeModeTab.Type m_257962_() {
      return this.f_256819_;
   }

   public void m_269498_(CreativeModeTab.ItemDisplayParameters p_270156_) {
      CreativeModeTab.ItemDisplayBuilder creativemodetab$itemdisplaybuilder = new CreativeModeTab.ItemDisplayBuilder(this, p_270156_.f_268709_);
      ResourceKey<CreativeModeTab> resourcekey = BuiltInRegistries.f_279662_.m_7854_(this).orElseThrow(() -> {
         return new IllegalStateException("Unregistered creative tab: " + this);
      });
      this.f_256824_.m_257865_(p_270156_, creativemodetab$itemdisplaybuilder);
      this.f_243839_ = creativemodetab$itemdisplaybuilder.f_244363_;
      this.f_243841_ = creativemodetab$itemdisplaybuilder.f_244585_;
      this.m_257466_();
   }

   public Collection<ItemStack> m_260957_() {
      return this.f_243839_;
   }

   public Collection<ItemStack> m_261235_() {
      return this.f_243841_;
   }

   public boolean m_257694_(ItemStack p_259317_) {
      return this.f_243841_.contains(p_259317_);
   }

   public void m_257882_(Consumer<List<ItemStack>> p_259669_) {
      this.f_256965_ = p_259669_;
   }

   public void m_257466_() {
      if (this.f_256965_ != null) {
         this.f_256965_.accept(Lists.newArrayList(this.f_243841_));
      }

   }

   public static class Builder {
      private static final CreativeModeTab.DisplayItemsGenerator f_256756_ = (p_270422_, p_259433_) -> {
      };
      private final CreativeModeTab.Row f_256796_;
      private final int f_256977_;
      private Component f_256856_ = Component.m_237119_();
      private Supplier<ItemStack> f_256981_ = () -> {
         return ItemStack.f_41583_;
      };
      private CreativeModeTab.DisplayItemsGenerator f_256953_ = f_256756_;
      private boolean f_256992_ = true;
      private boolean f_256851_ = true;
      private boolean f_256854_ = false;
      private CreativeModeTab.Type f_256847_ = CreativeModeTab.Type.CATEGORY;
      private String f_257036_ = "items.png";

      public Builder(CreativeModeTab.Row p_259171_, int p_259661_) {
         this.f_256796_ = p_259171_;
         this.f_256977_ = p_259661_;
      }

      public CreativeModeTab.Builder m_257941_(Component p_259616_) {
         this.f_256856_ = p_259616_;
         return this;
      }

      public CreativeModeTab.Builder m_257737_(Supplier<ItemStack> p_259333_) {
         this.f_256981_ = p_259333_;
         return this;
      }

      public CreativeModeTab.Builder m_257501_(CreativeModeTab.DisplayItemsGenerator p_259814_) {
         this.f_256953_ = p_259814_;
         return this;
      }

      public CreativeModeTab.Builder m_257826_() {
         this.f_256854_ = true;
         return this;
      }

      public CreativeModeTab.Builder m_257809_() {
         this.f_256851_ = false;
         return this;
      }

      public CreativeModeTab.Builder m_257794_() {
         this.f_256992_ = false;
         return this;
      }

      protected CreativeModeTab.Builder m_257623_(CreativeModeTab.Type p_259283_) {
         this.f_256847_ = p_259283_;
         return this;
      }

      public CreativeModeTab.Builder m_257609_(String p_259981_) {
         this.f_257036_ = p_259981_;
         return this;
      }

      public CreativeModeTab m_257652_() {
         if ((this.f_256847_ == CreativeModeTab.Type.HOTBAR || this.f_256847_ == CreativeModeTab.Type.INVENTORY) && this.f_256953_ != f_256756_) {
            throw new IllegalStateException("Special tabs can't have display items");
         } else {
            CreativeModeTab creativemodetab = new CreativeModeTab(this.f_256796_, this.f_256977_, this.f_256847_, this.f_256856_, this.f_256981_, this.f_256953_);
            creativemodetab.f_257018_ = this.f_256854_;
            creativemodetab.f_40768_ = this.f_256851_;
            creativemodetab.f_40767_ = this.f_256992_;
            creativemodetab.f_40766_ = this.f_257036_;
            return creativemodetab;
         }
      }
   }

   @FunctionalInterface
   public interface DisplayItemsGenerator {
      void m_257865_(CreativeModeTab.ItemDisplayParameters p_270258_, CreativeModeTab.Output p_259752_);
   }

   static class ItemDisplayBuilder implements CreativeModeTab.Output {
      public final Collection<ItemStack> f_244363_ = ItemStackLinkedSet.m_261170_();
      public final Set<ItemStack> f_244585_ = ItemStackLinkedSet.m_261170_();
      private final CreativeModeTab f_244054_;
      private final FeatureFlagSet f_243878_;

      public ItemDisplayBuilder(CreativeModeTab p_251040_, FeatureFlagSet p_249331_) {
         this.f_244054_ = p_251040_;
         this.f_243878_ = p_249331_;
      }

      public void m_246267_(ItemStack p_250391_, CreativeModeTab.TabVisibility p_251472_) {
         if (p_250391_.m_41613_() != 1) {
            throw new IllegalArgumentException("Stack size must be exactly 1");
         } else {
            boolean flag = this.f_244363_.contains(p_250391_) && p_251472_ != CreativeModeTab.TabVisibility.SEARCH_TAB_ONLY;
            if (flag) {
               throw new IllegalStateException("Accidentally adding the same item stack twice " + p_250391_.m_41611_().getString() + " to a Creative Mode Tab: " + this.f_244054_.m_40786_().getString());
            } else {
               if (p_250391_.m_41720_().m_245993_(this.f_243878_)) {
                  switch (p_251472_) {
                     case PARENT_AND_SEARCH_TABS:
                        this.f_244363_.add(p_250391_);
                        this.f_244585_.add(p_250391_);
                        break;
                     case PARENT_TAB_ONLY:
                        this.f_244363_.add(p_250391_);
                        break;
                     case SEARCH_TAB_ONLY:
                        this.f_244585_.add(p_250391_);
                  }
               }

            }
         }
      }
   }

   public static record ItemDisplayParameters(FeatureFlagSet f_268709_, boolean f_268429_, HolderLookup.Provider f_268485_) {
      public boolean m_269247_(FeatureFlagSet p_270338_, boolean p_270835_, HolderLookup.Provider p_270575_) {
         return !this.f_268709_.equals(p_270338_) || this.f_268429_ != p_270835_ || this.f_268485_ != p_270575_;
      }
   }

   public interface Output {
      void m_246267_(ItemStack p_251806_, CreativeModeTab.TabVisibility p_249603_);

      default void m_246342_(ItemStack p_249977_) {
         this.m_246267_(p_249977_, CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
      }

      default void m_245282_(ItemLike p_251528_, CreativeModeTab.TabVisibility p_249821_) {
         this.m_246267_(new ItemStack(p_251528_), p_249821_);
      }

      default void m_246326_(ItemLike p_248610_) {
         this.m_246267_(new ItemStack(p_248610_), CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
      }

      default void m_246233_(Collection<ItemStack> p_251548_, CreativeModeTab.TabVisibility p_252285_) {
         p_251548_.forEach((p_252337_) -> {
            this.m_246267_(p_252337_, p_252285_);
         });
      }

      default void m_246601_(Collection<ItemStack> p_250244_) {
         this.m_246233_(p_250244_, CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
      }
   }

   public static enum Row {
      TOP,
      BOTTOM;
   }

   protected static enum TabVisibility {
      PARENT_AND_SEARCH_TABS,
      PARENT_TAB_ONLY,
      SEARCH_TAB_ONLY;
   }

   public static enum Type {
      CATEGORY,
      INVENTORY,
      HOTBAR,
      SEARCH;
   }
}