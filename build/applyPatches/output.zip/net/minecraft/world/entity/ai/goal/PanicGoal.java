package net.minecraft.world.entity.ai.goal;

import java.util.EnumSet;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;

public class PanicGoal extends Goal {
   public static final int f_198171_ = 1;
   protected final PathfinderMob f_25684_;
   protected final double f_25685_;
   protected double f_25686_;
   protected double f_25687_;
   protected double f_25688_;
   protected boolean f_25689_;

   public PanicGoal(PathfinderMob p_25691_, double p_25692_) {
      this.f_25684_ = p_25691_;
      this.f_25685_ = p_25692_;
      this.m_7021_(EnumSet.of(Goal.Flag.MOVE));
   }

   public boolean m_8036_() {
      if (!this.m_202729_()) {
         return false;
      } else {
         if (this.f_25684_.m_6060_()) {
            BlockPos blockpos = this.m_198172_(this.f_25684_.m_9236_(), this.f_25684_, 5);
            if (blockpos != null) {
               this.f_25686_ = (double)blockpos.m_123341_();
               this.f_25687_ = (double)blockpos.m_123342_();
               this.f_25688_ = (double)blockpos.m_123343_();
               return true;
            }
         }

         return this.m_25702_();
      }
   }

   protected boolean m_202729_() {
      return this.f_25684_.m_21188_() != null || this.f_25684_.m_203117_() || this.f_25684_.m_6060_();
   }

   protected boolean m_25702_() {
      Vec3 vec3 = DefaultRandomPos.m_148403_(this.f_25684_, 5, 4);
      if (vec3 == null) {
         return false;
      } else {
         this.f_25686_ = vec3.f_82479_;
         this.f_25687_ = vec3.f_82480_;
         this.f_25688_ = vec3.f_82481_;
         return true;
      }
   }

   public boolean m_25703_() {
      return this.f_25689_;
   }

   public void m_8056_() {
      this.f_25684_.m_21573_().m_26519_(this.f_25686_, this.f_25687_, this.f_25688_, this.f_25685_);
      this.f_25689_ = true;
   }

   public void m_8041_() {
      this.f_25689_ = false;
   }

   public boolean m_8045_() {
      return !this.f_25684_.m_21573_().m_26571_();
   }

   @Nullable
   protected BlockPos m_198172_(BlockGetter p_198173_, Entity p_198174_, int p_198175_) {
      BlockPos blockpos = p_198174_.m_20183_();
      return !p_198173_.m_8055_(blockpos).m_60812_(p_198173_, blockpos).m_83281_() ? null : BlockPos.m_121930_(p_198174_.m_20183_(), p_198175_, 1, (p_196649_) -> {
         return p_198173_.m_6425_(p_196649_).m_205070_(FluidTags.f_13131_);
      }).orElse((BlockPos)null);
   }
}