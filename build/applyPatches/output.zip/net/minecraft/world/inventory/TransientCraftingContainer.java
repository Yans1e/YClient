package net.minecraft.world.inventory;

import java.util.List;
import net.minecraft.core.NonNullList;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.StackedContents;
import net.minecraft.world.item.ItemStack;

public class TransientCraftingContainer implements CraftingContainer {
   private final NonNullList<ItemStack> f_286951_;
   private final int f_286956_;
   private final int f_286972_;
   private final AbstractContainerMenu f_286998_;

   public TransientCraftingContainer(AbstractContainerMenu p_287684_, int p_287629_, int p_287593_) {
      this(p_287684_, p_287629_, p_287593_, NonNullList.m_122780_(p_287629_ * p_287593_, ItemStack.f_41583_));
   }

   public TransientCraftingContainer(AbstractContainerMenu p_287708_, int p_287591_, int p_287609_, NonNullList<ItemStack> p_287695_) {
      this.f_286951_ = p_287695_;
      this.f_286998_ = p_287708_;
      this.f_286956_ = p_287591_;
      this.f_286972_ = p_287609_;
   }

   public int m_6643_() {
      return this.f_286951_.size();
   }

   public boolean m_7983_() {
      for(ItemStack itemstack : this.f_286951_) {
         if (!itemstack.m_41619_()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack m_8020_(int p_287712_) {
      return p_287712_ >= this.m_6643_() ? ItemStack.f_41583_ : this.f_286951_.get(p_287712_);
   }

   public ItemStack m_8016_(int p_287637_) {
      return ContainerHelper.m_18966_(this.f_286951_, p_287637_);
   }

   public ItemStack m_7407_(int p_287682_, int p_287576_) {
      ItemStack itemstack = ContainerHelper.m_18969_(this.f_286951_, p_287682_, p_287576_);
      if (!itemstack.m_41619_()) {
         this.f_286998_.m_6199_(this);
      }

      return itemstack;
   }

   public void m_6836_(int p_287681_, ItemStack p_287620_) {
      this.f_286951_.set(p_287681_, p_287620_);
      this.f_286998_.m_6199_(this);
   }

   public void m_6596_() {
   }

   public boolean m_6542_(Player p_287774_) {
      return true;
   }

   public void m_6211_() {
      this.f_286951_.clear();
   }

   public int m_39346_() {
      return this.f_286972_;
   }

   public int m_39347_() {
      return this.f_286956_;
   }

   public List<ItemStack> m_280657_() {
      return List.copyOf(this.f_286951_);
   }

   public void m_5809_(StackedContents p_287653_) {
      for(ItemStack itemstack : this.f_286951_) {
         p_287653_.m_36466_(itemstack);
      }

   }
}