package net.minecraft.world.inventory;

public interface ContainerData {
   int m_6413_(int p_39284_);

   void m_8050_(int p_39285_, int p_39286_);

   int m_6499_();
}