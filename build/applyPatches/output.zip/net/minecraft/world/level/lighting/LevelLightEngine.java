package net.minecraft.world.level.lighting;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.chunk.DataLayer;
import net.minecraft.world.level.chunk.LightChunkGetter;

public class LevelLightEngine implements LightEventListener {
   public static final int f_164444_ = 1;
   protected final LevelHeightAccessor f_164445_;
   @Nullable
   private final LightEngine<?, ?> f_75802_;
   @Nullable
   private final LightEngine<?, ?> f_75803_;

   public LevelLightEngine(LightChunkGetter p_75805_, boolean p_75806_, boolean p_75807_) {
      this.f_164445_ = p_75805_.m_7653_();
      this.f_75802_ = p_75806_ ? new BlockLightEngine(p_75805_) : null;
      this.f_75803_ = p_75807_ ? new SkyLightEngine(p_75805_) : null;
   }

   public void m_7174_(BlockPos p_75823_) {
      if (this.f_75802_ != null) {
         this.f_75802_.m_7174_(p_75823_);
      }

      if (this.f_75803_ != null) {
         this.f_75803_.m_7174_(p_75823_);
      }

   }

   public boolean m_75808_() {
      if (this.f_75803_ != null && this.f_75803_.m_75808_()) {
         return true;
      } else {
         return this.f_75802_ != null && this.f_75802_.m_75808_();
      }
   }

   public int m_9323_() {
      int i = 0;
      if (this.f_75802_ != null) {
         i += this.f_75802_.m_9323_();
      }

      if (this.f_75803_ != null) {
         i += this.f_75803_.m_9323_();
      }

      return i;
   }

   public void m_6191_(SectionPos p_75827_, boolean p_75828_) {
      if (this.f_75802_ != null) {
         this.f_75802_.m_6191_(p_75827_, p_75828_);
      }

      if (this.f_75803_ != null) {
         this.f_75803_.m_6191_(p_75827_, p_75828_);
      }

   }

   public void m_9335_(ChunkPos p_285439_, boolean p_285012_) {
      if (this.f_75802_ != null) {
         this.f_75802_.m_9335_(p_285439_, p_285012_);
      }

      if (this.f_75803_ != null) {
         this.f_75803_.m_9335_(p_285439_, p_285012_);
      }

   }

   public void m_142519_(ChunkPos p_284998_) {
      if (this.f_75802_ != null) {
         this.f_75802_.m_142519_(p_284998_);
      }

      if (this.f_75803_ != null) {
         this.f_75803_.m_142519_(p_284998_);
      }

   }

   public LayerLightEventListener m_75814_(LightLayer p_75815_) {
      if (p_75815_ == LightLayer.BLOCK) {
         return (LayerLightEventListener)(this.f_75802_ == null ? LayerLightEventListener.DummyLightLayerEventListener.INSTANCE : this.f_75802_);
      } else {
         return (LayerLightEventListener)(this.f_75803_ == null ? LayerLightEventListener.DummyLightLayerEventListener.INSTANCE : this.f_75803_);
      }
   }

   public String m_75816_(LightLayer p_75817_, SectionPos p_75818_) {
      if (p_75817_ == LightLayer.BLOCK) {
         if (this.f_75802_ != null) {
            return this.f_75802_.m_284216_(p_75818_.m_123252_());
         }
      } else if (this.f_75803_ != null) {
         return this.f_75803_.m_284216_(p_75818_.m_123252_());
      }

      return "n/a";
   }

   public LayerLightSectionStorage.SectionType m_284493_(LightLayer p_285008_, SectionPos p_285336_) {
      if (p_285008_ == LightLayer.BLOCK) {
         if (this.f_75802_ != null) {
            return this.f_75802_.m_284437_(p_285336_.m_123252_());
         }
      } else if (this.f_75803_ != null) {
         return this.f_75803_.m_284437_(p_285336_.m_123252_());
      }

      return LayerLightSectionStorage.SectionType.EMPTY;
   }

   public void m_284126_(LightLayer p_285328_, SectionPos p_284962_, @Nullable DataLayer p_285035_) {
      if (p_285328_ == LightLayer.BLOCK) {
         if (this.f_75802_ != null) {
            this.f_75802_.m_284203_(p_284962_.m_123252_(), p_285035_);
         }
      } else if (this.f_75803_ != null) {
         this.f_75803_.m_284203_(p_284962_.m_123252_(), p_285035_);
      }

   }

   public void m_6462_(ChunkPos p_75829_, boolean p_75830_) {
      if (this.f_75802_ != null) {
         this.f_75802_.m_284245_(p_75829_, p_75830_);
      }

      if (this.f_75803_ != null) {
         this.f_75803_.m_284245_(p_75829_, p_75830_);
      }

   }

   public int m_75831_(BlockPos p_75832_, int p_75833_) {
      int i = this.f_75803_ == null ? 0 : this.f_75803_.m_7768_(p_75832_) - p_75833_;
      int j = this.f_75802_ == null ? 0 : this.f_75802_.m_7768_(p_75832_);
      return Math.max(j, i);
   }

   public boolean m_284439_(SectionPos p_285319_) {
      long i = p_285319_.m_123252_();
      return this.f_75802_ == null || this.f_75802_.f_283849_.m_284382_(i) && (this.f_75803_ == null || this.f_75803_.f_283849_.m_284382_(i));
   }

   public int m_164446_() {
      return this.f_164445_.m_151559_() + 2;
   }

   public int m_164447_() {
      return this.f_164445_.m_151560_() - 1;
   }

   public int m_164448_() {
      return this.m_164447_() + this.m_164446_();
   }
}