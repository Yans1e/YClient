package net.minecraft.world.level.portal;

import net.minecraft.world.phys.Vec3;

public class PortalInfo {
   public final Vec3 f_77676_;
   public final Vec3 f_77677_;
   public final float f_77678_;
   public final float f_77679_;

   public PortalInfo(Vec3 p_77681_, Vec3 p_77682_, float p_77683_, float p_77684_) {
      this.f_77676_ = p_77681_;
      this.f_77677_ = p_77682_;
      this.f_77678_ = p_77683_;
      this.f_77679_ = p_77684_;
   }
}