package net.minecraft.world.level.block;

import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class StemBlock extends BushBlock implements BonemealableBlock {
   public static final int f_154724_ = 7;
   public static final IntegerProperty f_57013_ = BlockStateProperties.f_61409_;
   protected static final float f_154725_ = 1.0F;
   protected static final VoxelShape[] f_57014_ = new VoxelShape[]{Block.m_49796_(7.0D, 0.0D, 7.0D, 9.0D, 2.0D, 9.0D), Block.m_49796_(7.0D, 0.0D, 7.0D, 9.0D, 4.0D, 9.0D), Block.m_49796_(7.0D, 0.0D, 7.0D, 9.0D, 6.0D, 9.0D), Block.m_49796_(7.0D, 0.0D, 7.0D, 9.0D, 8.0D, 9.0D), Block.m_49796_(7.0D, 0.0D, 7.0D, 9.0D, 10.0D, 9.0D), Block.m_49796_(7.0D, 0.0D, 7.0D, 9.0D, 12.0D, 9.0D), Block.m_49796_(7.0D, 0.0D, 7.0D, 9.0D, 14.0D, 9.0D), Block.m_49796_(7.0D, 0.0D, 7.0D, 9.0D, 16.0D, 9.0D)};
   private final StemGrownBlock f_57015_;
   private final Supplier<Item> f_154726_;

   protected StemBlock(StemGrownBlock p_154728_, Supplier<Item> p_154729_, BlockBehaviour.Properties p_154730_) {
      super(p_154730_);
      this.f_57015_ = p_154728_;
      this.f_154726_ = p_154729_;
      this.m_49959_(this.f_49792_.m_61090_().m_61124_(f_57013_, Integer.valueOf(0)));
   }

   public VoxelShape m_5940_(BlockState p_57047_, BlockGetter p_57048_, BlockPos p_57049_, CollisionContext p_57050_) {
      return f_57014_[p_57047_.m_61143_(f_57013_)];
   }

   protected boolean m_6266_(BlockState p_57053_, BlockGetter p_57054_, BlockPos p_57055_) {
      return p_57053_.m_60713_(Blocks.f_50093_);
   }

   public void m_213898_(BlockState p_222538_, ServerLevel p_222539_, BlockPos p_222540_, RandomSource p_222541_) {
      if (p_222539_.m_45524_(p_222540_, 0) >= 9) {
         float f = CropBlock.m_52272_(this, p_222539_, p_222540_);
         if (p_222541_.m_188503_((int)(25.0F / f) + 1) == 0) {
            int i = p_222538_.m_61143_(f_57013_);
            if (i < 7) {
               p_222538_ = p_222538_.m_61124_(f_57013_, Integer.valueOf(i + 1));
               p_222539_.m_7731_(p_222540_, p_222538_, 2);
            } else {
               Direction direction = Direction.Plane.HORIZONTAL.m_235690_(p_222541_);
               BlockPos blockpos = p_222540_.m_121945_(direction);
               BlockState blockstate = p_222539_.m_8055_(blockpos.m_7495_());
               if (p_222539_.m_8055_(blockpos).m_60795_() && (blockstate.m_60713_(Blocks.f_50093_) || blockstate.m_204336_(BlockTags.f_144274_))) {
                  p_222539_.m_46597_(blockpos, this.f_57015_.m_49966_());
                  p_222539_.m_46597_(p_222540_, this.f_57015_.m_7810_().m_49966_().m_61124_(HorizontalDirectionalBlock.f_54117_, direction));
               }
            }
         }

      }
   }

   public ItemStack m_7397_(BlockGetter p_57026_, BlockPos p_57027_, BlockState p_57028_) {
      return new ItemStack(this.f_154726_.get());
   }

   public boolean m_7370_(LevelReader p_255699_, BlockPos p_57031_, BlockState p_57032_) {
      return p_57032_.m_61143_(f_57013_) != 7;
   }

   public boolean m_214167_(Level p_222533_, RandomSource p_222534_, BlockPos p_222535_, BlockState p_222536_) {
      return true;
   }

   public void m_214148_(ServerLevel p_222528_, RandomSource p_222529_, BlockPos p_222530_, BlockState p_222531_) {
      int i = Math.min(7, p_222531_.m_61143_(f_57013_) + Mth.m_216271_(p_222528_.f_46441_, 2, 5));
      BlockState blockstate = p_222531_.m_61124_(f_57013_, Integer.valueOf(i));
      p_222528_.m_7731_(p_222530_, blockstate, 2);
      if (i == 7) {
         blockstate.m_222972_(p_222528_, p_222530_, p_222528_.f_46441_);
      }

   }

   protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_57040_) {
      p_57040_.m_61104_(f_57013_);
   }

   public StemGrownBlock m_57056_() {
      return this.f_57015_;
   }
}