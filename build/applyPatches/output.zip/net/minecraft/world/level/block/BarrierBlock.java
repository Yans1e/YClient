package net.minecraft.world.level.block;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;

public class BarrierBlock extends Block implements SimpleWaterloggedBlock {
   public static final BooleanProperty f_291429_ = BlockStateProperties.f_61362_;

   protected BarrierBlock(BlockBehaviour.Properties p_49092_) {
      super(p_49092_);
      this.m_49959_(this.m_49966_().m_61124_(f_291429_, Boolean.valueOf(false)));
   }

   public boolean m_7420_(BlockState p_49100_, BlockGetter p_49101_, BlockPos p_49102_) {
      return true;
   }

   public RenderShape m_7514_(BlockState p_49098_) {
      return RenderShape.INVISIBLE;
   }

   public float m_7749_(BlockState p_49094_, BlockGetter p_49095_, BlockPos p_49096_) {
      return 1.0F;
   }

   public BlockState m_7417_(BlockState p_298183_, Direction p_298685_, BlockState p_298648_, LevelAccessor p_299709_, BlockPos p_297885_, BlockPos p_299701_) {
      if (p_298183_.m_61143_(f_291429_)) {
         p_299709_.m_186469_(p_297885_, Fluids.f_76193_, Fluids.f_76193_.m_6718_(p_299709_));
      }

      return super.m_7417_(p_298183_, p_298685_, p_298648_, p_299709_, p_297885_, p_299701_);
   }

   public FluidState m_5888_(BlockState p_301306_) {
      return p_301306_.m_61143_(f_291429_) ? Fluids.f_76193_.m_76068_(false) : super.m_5888_(p_301306_);
   }

   @Nullable
   public BlockState m_5573_(BlockPlaceContext p_298919_) {
      return this.m_49966_().m_61124_(f_291429_, Boolean.valueOf(p_298919_.m_43725_().m_6425_(p_298919_.m_8083_()).m_76152_() == Fluids.f_76193_));
   }

   protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_297868_) {
      p_297868_.m_61104_(f_291429_);
   }

   public ItemStack m_142598_(@Nullable Player p_300115_, LevelAccessor p_299225_, BlockPos p_298270_, BlockState p_298275_) {
      return p_300115_ != null && p_300115_.m_7500_() ? SimpleWaterloggedBlock.super.m_142598_(p_300115_, p_299225_, p_298270_, p_298275_) : ItemStack.f_41583_;
   }

   public boolean m_6044_(@Nullable Player p_298257_, BlockGetter p_299765_, BlockPos p_297382_, BlockState p_299344_, Fluid p_299153_) {
      return p_298257_ != null && p_298257_.m_7500_() ? SimpleWaterloggedBlock.super.m_6044_(p_298257_, p_299765_, p_297382_, p_299344_, p_299153_) : false;
   }
}