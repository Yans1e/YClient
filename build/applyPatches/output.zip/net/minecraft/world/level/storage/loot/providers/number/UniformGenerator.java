package net.minecraft.world.level.storage.loot.providers.number;

import com.google.common.collect.Sets;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Set;
import net.minecraft.util.Mth;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParam;

public record UniformGenerator(NumberProvider f_165774_, NumberProvider f_165775_) implements NumberProvider {
   public static final Codec<UniformGenerator> f_291637_ = RecordCodecBuilder.create((p_299644_) -> {
      return p_299644_.group(NumberProviders.f_291751_.fieldOf("min").forGetter(UniformGenerator::f_165774_), NumberProviders.f_291751_.fieldOf("max").forGetter(UniformGenerator::f_165775_)).apply(p_299644_, UniformGenerator::new);
   });

   public LootNumberProviderType m_142587_() {
      return NumberProviders.f_165732_;
   }

   public static UniformGenerator m_165780_(float p_165781_, float p_165782_) {
      return new UniformGenerator(ConstantValue.m_165692_(p_165781_), ConstantValue.m_165692_(p_165782_));
   }

   public int m_142683_(LootContext p_165784_) {
      return Mth.m_216271_(p_165784_.m_230907_(), this.f_165774_.m_142683_(p_165784_), this.f_165775_.m_142683_(p_165784_));
   }

   public float m_142688_(LootContext p_165787_) {
      return Mth.m_216267_(p_165787_.m_230907_(), this.f_165774_.m_142688_(p_165787_), this.f_165775_.m_142688_(p_165787_));
   }

   public Set<LootContextParam<?>> m_6231_() {
      return Sets.union(this.f_165774_.m_6231_(), this.f_165775_.m_6231_());
   }
}