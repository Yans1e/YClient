package net.minecraft.world.level.storage.loot.predicates;

import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParam;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

public record BonusLevelTableCondition(Holder<Enchantment> f_81507_, List<Float> f_81508_) implements LootItemCondition {
   public static final Codec<BonusLevelTableCondition> f_291274_ = RecordCodecBuilder.create((p_297182_) -> {
      return p_297182_.group(BuiltInRegistries.f_256876_.m_206110_().fieldOf("enchantment").forGetter(BonusLevelTableCondition::f_81507_), Codec.FLOAT.listOf().fieldOf("chances").forGetter(BonusLevelTableCondition::f_81508_)).apply(p_297182_, BonusLevelTableCondition::new);
   });

   public LootItemConditionType m_7940_() {
      return LootItemConditions.f_81820_;
   }

   public Set<LootContextParam<?>> m_6231_() {
      return ImmutableSet.of(LootContextParams.f_81463_);
   }

   public boolean test(LootContext p_81521_) {
      ItemStack itemstack = p_81521_.m_78953_(LootContextParams.f_81463_);
      int i = itemstack != null ? EnchantmentHelper.m_44843_(this.f_81507_.m_203334_(), itemstack) : 0;
      float f = this.f_81508_.get(Math.min(i, this.f_81508_.size() - 1));
      return p_81521_.m_230907_().m_188501_() < f;
   }

   public static LootItemCondition.Builder m_81517_(Enchantment p_81518_, float... p_81519_) {
      List<Float> list = new ArrayList<>(p_81519_.length);

      for(float f : p_81519_) {
         list.add(f);
      }

      return () -> {
         return new BonusLevelTableCondition(p_81518_.m_292589_(), list);
      };
   }
}