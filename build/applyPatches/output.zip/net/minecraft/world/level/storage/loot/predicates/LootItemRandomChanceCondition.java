package net.minecraft.world.level.storage.loot.predicates;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.world.level.storage.loot.LootContext;

public record LootItemRandomChanceCondition(float f_81921_) implements LootItemCondition {
   public static final Codec<LootItemRandomChanceCondition> f_290849_ = RecordCodecBuilder.create((p_297204_) -> {
      return p_297204_.group(Codec.FLOAT.fieldOf("chance").forGetter(LootItemRandomChanceCondition::f_81921_)).apply(p_297204_, LootItemRandomChanceCondition::new);
   });

   public LootItemConditionType m_7940_() {
      return LootItemConditions.f_81813_;
   }

   public boolean test(LootContext p_81930_) {
      return p_81930_.m_230907_().m_188501_() < this.f_81921_;
   }

   public static LootItemCondition.Builder m_81927_(float p_81928_) {
      return () -> {
         return new LootItemRandomChanceCondition(p_81928_);
      };
   }
}