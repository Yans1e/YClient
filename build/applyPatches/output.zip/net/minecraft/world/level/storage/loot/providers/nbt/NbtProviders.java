package net.minecraft.world.level.storage.loot.providers.nbt;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ExtraCodecs;

public class NbtProviders {
   private static final Codec<NbtProvider> f_290422_ = BuiltInRegistries.f_256736_.m_194605_().dispatch(NbtProvider::m_142624_, LootNbtProviderType::f_290507_);
   public static final Codec<NbtProvider> f_290907_ = ExtraCodecs.m_184415_(() -> {
      return Codec.either(ContextNbtProvider.f_290817_, f_290422_).xmap((p_298461_) -> {
         return p_298461_.map(Function.identity(), Function.identity());
      }, (p_298663_) -> {
         Either either;
         if (p_298663_ instanceof ContextNbtProvider contextnbtprovider) {
            either = Either.left(contextnbtprovider);
         } else {
            either = Either.right(p_298663_);
         }

         return either;
      });
   });
   public static final LootNbtProviderType f_165623_ = m_165628_("storage", StorageNbtProvider.f_290459_);
   public static final LootNbtProviderType f_165624_ = m_165628_("context", ContextNbtProvider.f_291532_);

   private static LootNbtProviderType m_165628_(String p_165629_, Codec<? extends NbtProvider> p_300005_) {
      return Registry.m_122965_(BuiltInRegistries.f_256736_, new ResourceLocation(p_165629_), new LootNbtProviderType(p_300005_));
   }
}