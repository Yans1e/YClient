package net.minecraft.world.level.storage.loot.entries;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.Products;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.ValidationContext;
import net.minecraft.world.level.storage.loot.predicates.ConditionUserBuilder;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemConditions;

public abstract class LootPoolEntryContainer implements ComposableEntryContainer {
   protected final List<LootItemCondition> f_79636_;
   private final Predicate<LootContext> f_79635_;

   protected LootPoolEntryContainer(List<LootItemCondition> p_298327_) {
      this.f_79636_ = p_298327_;
      this.f_79635_ = LootItemConditions.m_81834_(p_298327_);
   }

   protected static <T extends LootPoolEntryContainer> Products.P1<RecordCodecBuilder.Mu<T>, List<LootItemCondition>> m_293334_(RecordCodecBuilder.Instance<T> p_297717_) {
      return p_297717_.group(ExtraCodecs.m_295827_(LootItemConditions.f_290534_.listOf(), "conditions", List.of()).forGetter((p_297410_) -> {
         return p_297410_.f_79636_;
      }));
   }

   public void m_6165_(ValidationContext p_79641_) {
      for(int i = 0; i < this.f_79636_.size(); ++i) {
         this.f_79636_.get(i).m_6169_(p_79641_.m_79365_(".condition[" + i + "]"));
      }

   }

   protected final boolean m_79639_(LootContext p_79640_) {
      return this.f_79635_.test(p_79640_);
   }

   public abstract LootPoolEntryType m_6751_();

   public abstract static class Builder<T extends LootPoolEntryContainer.Builder<T>> implements ConditionUserBuilder<T> {
      private final ImmutableList.Builder<LootItemCondition> f_79642_ = ImmutableList.builder();

      protected abstract T m_6897_();

      public T m_79080_(LootItemCondition.Builder p_79646_) {
         this.f_79642_.add(p_79646_.m_6409_());
         return this.m_6897_();
      }

      public final T m_79073_() {
         return this.m_6897_();
      }

      protected List<LootItemCondition> m_79651_() {
         return this.f_79642_.build();
      }

      public AlternativesEntry.Builder m_7170_(LootPoolEntryContainer.Builder<?> p_79644_) {
         return new AlternativesEntry.Builder(this, p_79644_);
      }

      public EntryGroup.Builder m_142719_(LootPoolEntryContainer.Builder<?> p_165148_) {
         return new EntryGroup.Builder(this, p_165148_);
      }

      public SequentialEntry.Builder m_142639_(LootPoolEntryContainer.Builder<?> p_165149_) {
         return new SequentialEntry.Builder(this, p_165149_);
      }

      public abstract LootPoolEntryContainer m_7512_();
   }
}