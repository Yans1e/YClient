package net.minecraft.world.level.storage.loot.providers.number;

import com.google.common.collect.Sets;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Set;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParam;

public record BinomialDistributionGenerator(NumberProvider f_165653_, NumberProvider f_165654_) implements NumberProvider {
   public static final Codec<BinomialDistributionGenerator> f_290666_ = RecordCodecBuilder.create((p_297459_) -> {
      return p_297459_.group(NumberProviders.f_291751_.fieldOf("n").forGetter(BinomialDistributionGenerator::f_165653_), NumberProviders.f_291751_.fieldOf("p").forGetter(BinomialDistributionGenerator::f_165654_)).apply(p_297459_, BinomialDistributionGenerator::new);
   });

   public LootNumberProviderType m_142587_() {
      return NumberProviders.f_165733_;
   }

   public int m_142683_(LootContext p_165663_) {
      int i = this.f_165653_.m_142683_(p_165663_);
      float f = this.f_165654_.m_142688_(p_165663_);
      RandomSource randomsource = p_165663_.m_230907_();
      int j = 0;

      for(int k = 0; k < i; ++k) {
         if (randomsource.m_188501_() < f) {
            ++j;
         }
      }

      return j;
   }

   public float m_142688_(LootContext p_165666_) {
      return (float)this.m_142683_(p_165666_);
   }

   public static BinomialDistributionGenerator m_165659_(int p_165660_, float p_165661_) {
      return new BinomialDistributionGenerator(ConstantValue.m_165692_((float)p_165660_), ConstantValue.m_165692_(p_165661_));
   }

   public Set<LootContextParam<?>> m_6231_() {
      return Sets.union(this.f_165653_.m_6231_(), this.f_165654_.m_6231_());
   }
}