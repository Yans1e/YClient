package net.minecraft.world.level.storage.loot.functions;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import org.slf4j.Logger;

public class EnchantRandomlyFunction extends LootItemConditionalFunction {
   private static final Logger f_80414_ = LogUtils.getLogger();
   private static final Codec<HolderSet<Enchantment>> f_291886_ = BuiltInRegistries.f_256876_.m_206110_().listOf().xmap(HolderSet::m_205800_, (p_297089_) -> {
      return p_297089_.m_203614_().toList();
   });
   public static final Codec<EnchantRandomlyFunction> f_291046_ = RecordCodecBuilder.create((p_297085_) -> {
      return m_294820_(p_297085_).and(ExtraCodecs.m_294263_(f_291886_, "enchantments").forGetter((p_297084_) -> {
         return p_297084_.f_80415_;
      })).apply(p_297085_, EnchantRandomlyFunction::new);
   });
   private final Optional<HolderSet<Enchantment>> f_80415_;

   EnchantRandomlyFunction(List<LootItemCondition> p_298352_, Optional<HolderSet<Enchantment>> p_297532_) {
      super(p_298352_);
      this.f_80415_ = p_297532_;
   }

   public LootItemFunctionType m_7162_() {
      return LootItemFunctions.f_80738_;
   }

   public ItemStack m_7372_(ItemStack p_80429_, LootContext p_80430_) {
      RandomSource randomsource = p_80430_.m_230907_();
      Optional<Holder<Enchantment>> optional = this.f_80415_.flatMap((p_297095_) -> {
         return p_297095_.m_213653_(randomsource);
      }).or(() -> {
         boolean flag = p_80429_.m_150930_(Items.f_42517_);
         List<Holder.Reference<Enchantment>> list = BuiltInRegistries.f_256876_.m_203611_().filter((p_297090_) -> {
            return p_297090_.m_203334_().m_6592_();
         }).filter((p_297093_) -> {
            return flag || p_297093_.m_203334_().m_6081_(p_80429_);
         }).toList();
         return Util.m_214676_(list, randomsource);
      });
      if (optional.isEmpty()) {
         f_80414_.warn("Couldn't find a compatible enchantment for {}", (Object)p_80429_);
         return p_80429_;
      } else {
         return m_230979_(p_80429_, optional.get().m_203334_(), randomsource);
      }
   }

   private static ItemStack m_230979_(ItemStack p_230980_, Enchantment p_230981_, RandomSource p_230982_) {
      int i = Mth.m_216271_(p_230982_, p_230981_.m_44702_(), p_230981_.m_6586_());
      if (p_230980_.m_150930_(Items.f_42517_)) {
         p_230980_ = new ItemStack(Items.f_42690_);
         EnchantedBookItem.m_41153_(p_230980_, new EnchantmentInstance(p_230981_, i));
      } else {
         p_230980_.m_41663_(p_230981_, i);
      }

      return p_230980_;
   }

   public static EnchantRandomlyFunction.Builder m_165191_() {
      return new EnchantRandomlyFunction.Builder();
   }

   public static LootItemConditionalFunction.Builder<?> m_80440_() {
      return m_80683_((p_297086_) -> {
         return new EnchantRandomlyFunction(p_297086_, Optional.empty());
      });
   }

   public static class Builder extends LootItemConditionalFunction.Builder<EnchantRandomlyFunction.Builder> {
      private final List<Holder<Enchantment>> f_80441_ = new ArrayList<>();

      protected EnchantRandomlyFunction.Builder m_6477_() {
         return this;
      }

      public EnchantRandomlyFunction.Builder m_80444_(Enchantment p_80445_) {
         this.f_80441_.add(p_80445_.m_292589_());
         return this;
      }

      public LootItemFunction m_7453_() {
         return new EnchantRandomlyFunction(this.m_80699_(), this.f_80441_.isEmpty() ? Optional.empty() : Optional.of(HolderSet.m_205800_(this.f_80441_)));
      }
   }
}