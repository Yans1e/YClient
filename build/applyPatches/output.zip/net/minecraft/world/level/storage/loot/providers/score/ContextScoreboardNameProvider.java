package net.minecraft.world.level.storage.loot.providers.score;

import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParam;

public record ContextScoreboardNameProvider(LootContext.EntityTarget f_165803_) implements ScoreboardNameProvider {
   public static final Codec<ContextScoreboardNameProvider> f_290593_ = RecordCodecBuilder.create((p_297529_) -> {
      return p_297529_.group(LootContext.EntityTarget.f_291271_.fieldOf("target").forGetter(ContextScoreboardNameProvider::f_165803_)).apply(p_297529_, ContextScoreboardNameProvider::new);
   });
   public static final Codec<ContextScoreboardNameProvider> f_291014_ = LootContext.EntityTarget.f_291271_.xmap(ContextScoreboardNameProvider::new, ContextScoreboardNameProvider::f_165803_);

   public static ScoreboardNameProvider m_165807_(LootContext.EntityTarget p_165808_) {
      return new ContextScoreboardNameProvider(p_165808_);
   }

   public LootScoreProviderType m_142680_() {
      return ScoreboardNameProviders.f_165869_;
   }

   @Nullable
   public String m_142600_(LootContext p_165810_) {
      Entity entity = p_165810_.m_78953_(this.f_165803_.m_79003_());
      return entity != null ? entity.m_6302_() : null;
   }

   public Set<LootContextParam<?>> m_142636_() {
      return ImmutableSet.of(this.f_165803_.m_79003_());
   }
}