package net.minecraft.world.level.storage.loot.functions;

import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.MapLike;
import com.mojang.serialization.RecordBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParam;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;

public class ApplyBonusCount extends LootItemConditionalFunction {
   private static final Map<ResourceLocation, ApplyBonusCount.FormulaType> f_79898_ = Stream.of(ApplyBonusCount.BinomialWithBonusCount.f_79947_, ApplyBonusCount.OreDrops.f_79973_, ApplyBonusCount.UniformBonusCount.f_80012_).collect(Collectors.toMap(ApplyBonusCount.FormulaType::f_291058_, Function.identity()));
   static final Codec<ApplyBonusCount.FormulaType> f_291576_ = ResourceLocation.f_135803_.comapFlatMap((p_297073_) -> {
      ApplyBonusCount.FormulaType applybonuscount$formulatype = f_79898_.get(p_297073_);
      return applybonuscount$formulatype != null ? DataResult.success(applybonuscount$formulatype) : DataResult.error(() -> {
         return "No formula type with id: '" + p_297073_ + "'";
      });
   }, ApplyBonusCount.FormulaType::f_291058_);
   private static final MapCodec<ApplyBonusCount.Formula> f_290648_ = new MapCodec<ApplyBonusCount.Formula>() {
      private static final String f_290340_ = "formula";
      private static final String f_291858_ = "parameters";

      public <T> Stream<T> keys(DynamicOps<T> p_299919_) {
         return Stream.of(p_299919_.createString("formula"), p_299919_.createString("parameters"));
      }

      public <T> DataResult<ApplyBonusCount.Formula> decode(DynamicOps<T> p_297405_, MapLike<T> p_298221_) {
         T t = p_298221_.get("formula");
         return t == null ? DataResult.error(() -> {
            return "Missing type for formula in: " + p_298221_;
         }) : ApplyBonusCount.f_291576_.decode(p_297405_, t).flatMap((p_298653_) -> {
            T t1 = Objects.requireNonNullElseGet(p_298221_.get("parameters"), p_297405_::emptyMap);
            return p_298653_.getFirst().f_291691_().decode(p_297405_, t1).map(Pair::getFirst);
         });
      }

      public <T> RecordBuilder<T> encode(ApplyBonusCount.Formula p_299009_, DynamicOps<T> p_298702_, RecordBuilder<T> p_298118_) {
         ApplyBonusCount.FormulaType applybonuscount$formulatype = p_299009_.m_5713_();
         p_298118_.add("formula", ApplyBonusCount.f_291576_.encodeStart(p_298702_, applybonuscount$formulatype));
         DataResult<T> dataresult = this.m_293891_(applybonuscount$formulatype.f_291691_(), p_299009_, p_298702_);
         if (dataresult.result().isEmpty() || !Objects.equals(dataresult.result().get(), p_298702_.emptyMap())) {
            p_298118_.add("parameters", dataresult);
         }

         return p_298118_;
      }

      private <T, F extends ApplyBonusCount.Formula> DataResult<T> m_293891_(Codec<F> p_298015_, ApplyBonusCount.Formula p_298974_, DynamicOps<T> p_298875_) {
         return p_298015_.encodeStart(p_298875_, (F)p_298974_);
      }
   };
   public static final Codec<ApplyBonusCount> f_291250_ = RecordCodecBuilder.create((p_297066_) -> {
      return m_294820_(p_297066_).and(p_297066_.group(BuiltInRegistries.f_256876_.m_206110_().fieldOf("enchantment").forGetter((p_297072_) -> {
         return p_297072_.f_79899_;
      }), f_290648_.forGetter((p_297058_) -> {
         return p_297058_.f_79900_;
      }))).apply(p_297066_, ApplyBonusCount::new);
   });
   private final Holder<Enchantment> f_79899_;
   private final ApplyBonusCount.Formula f_79900_;

   private ApplyBonusCount(List<LootItemCondition> p_298095_, Holder<Enchantment> p_298508_, ApplyBonusCount.Formula p_79905_) {
      super(p_298095_);
      this.f_79899_ = p_298508_;
      this.f_79900_ = p_79905_;
   }

   public LootItemFunctionType m_7162_() {
      return LootItemFunctions.f_80750_;
   }

   public Set<LootContextParam<?>> m_6231_() {
      return ImmutableSet.of(LootContextParams.f_81463_);
   }

   public ItemStack m_7372_(ItemStack p_79913_, LootContext p_79914_) {
      ItemStack itemstack = p_79914_.m_78953_(LootContextParams.f_81463_);
      if (itemstack != null) {
         int i = EnchantmentHelper.m_44843_(this.f_79899_.m_203334_(), itemstack);
         int j = this.f_79900_.m_213779_(p_79914_.m_230907_(), p_79913_.m_41613_(), i);
         p_79913_.m_41764_(j);
      }

      return p_79913_;
   }

   public static LootItemConditionalFunction.Builder<?> m_79917_(Enchantment p_79918_, float p_79919_, int p_79920_) {
      return m_80683_((p_297062_) -> {
         return new ApplyBonusCount(p_297062_, p_79918_.m_292589_(), new ApplyBonusCount.BinomialWithBonusCount(p_79920_, p_79919_));
      });
   }

   public static LootItemConditionalFunction.Builder<?> m_79915_(Enchantment p_79916_) {
      return m_80683_((p_297064_) -> {
         return new ApplyBonusCount(p_297064_, p_79916_.m_292589_(), new ApplyBonusCount.OreDrops());
      });
   }

   public static LootItemConditionalFunction.Builder<?> m_79939_(Enchantment p_79940_) {
      return m_80683_((p_297068_) -> {
         return new ApplyBonusCount(p_297068_, p_79940_.m_292589_(), new ApplyBonusCount.UniformBonusCount(1));
      });
   }

   public static LootItemConditionalFunction.Builder<?> m_79921_(Enchantment p_79922_, int p_79923_) {
      return m_80683_((p_297071_) -> {
         return new ApplyBonusCount(p_297071_, p_79922_.m_292589_(), new ApplyBonusCount.UniformBonusCount(p_79923_));
      });
   }

   static record BinomialWithBonusCount(int f_79948_, float f_79949_) implements ApplyBonusCount.Formula {
      private static final Codec<ApplyBonusCount.BinomialWithBonusCount> f_290700_ = RecordCodecBuilder.create((p_299643_) -> {
         return p_299643_.group(Codec.INT.fieldOf("extra").forGetter(ApplyBonusCount.BinomialWithBonusCount::f_79948_), Codec.FLOAT.fieldOf("probability").forGetter(ApplyBonusCount.BinomialWithBonusCount::f_79949_)).apply(p_299643_, ApplyBonusCount.BinomialWithBonusCount::new);
      });
      public static final ApplyBonusCount.FormulaType f_79947_ = new ApplyBonusCount.FormulaType(new ResourceLocation("binomial_with_bonus_count"), f_290700_);

      public int m_213779_(RandomSource p_230965_, int p_230966_, int p_230967_) {
         for(int i = 0; i < p_230967_ + this.f_79948_; ++i) {
            if (p_230965_.m_188501_() < this.f_79949_) {
               ++p_230966_;
            }
         }

         return p_230966_;
      }

      public ApplyBonusCount.FormulaType m_5713_() {
         return f_79947_;
      }
   }

   interface Formula {
      int m_213779_(RandomSource p_230968_, int p_230969_, int p_230970_);

      ApplyBonusCount.FormulaType m_5713_();
   }

   static record FormulaType(ResourceLocation f_291058_, Codec<? extends ApplyBonusCount.Formula> f_291691_) {
   }

   static record OreDrops() implements ApplyBonusCount.Formula {
      public static final Codec<ApplyBonusCount.OreDrops> f_291282_ = Codec.unit(ApplyBonusCount.OreDrops::new);
      public static final ApplyBonusCount.FormulaType f_79973_ = new ApplyBonusCount.FormulaType(new ResourceLocation("ore_drops"), f_291282_);

      public int m_213779_(RandomSource p_230972_, int p_230973_, int p_230974_) {
         if (p_230974_ > 0) {
            int i = p_230972_.m_188503_(p_230974_ + 2) - 1;
            if (i < 0) {
               i = 0;
            }

            return p_230973_ * (i + 1);
         } else {
            return p_230973_;
         }
      }

      public ApplyBonusCount.FormulaType m_5713_() {
         return f_79973_;
      }
   }

   static record UniformBonusCount(int f_80013_) implements ApplyBonusCount.Formula {
      public static final Codec<ApplyBonusCount.UniformBonusCount> f_290477_ = RecordCodecBuilder.create((p_297464_) -> {
         return p_297464_.group(Codec.INT.fieldOf("bonusMultiplier").forGetter(ApplyBonusCount.UniformBonusCount::f_80013_)).apply(p_297464_, ApplyBonusCount.UniformBonusCount::new);
      });
      public static final ApplyBonusCount.FormulaType f_80012_ = new ApplyBonusCount.FormulaType(new ResourceLocation("uniform_bonus_count"), f_290477_);

      public int m_213779_(RandomSource p_230976_, int p_230977_, int p_230978_) {
         return p_230977_ + p_230976_.m_188503_(this.f_80013_ * p_230978_ + 1);
      }

      public ApplyBonusCount.FormulaType m_5713_() {
         return f_80012_;
      }
   }
}