package net.minecraft.world.level.storage.loot.predicates;

import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import java.util.Set;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParam;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

public record MatchTool(Optional<ItemPredicate> f_81993_) implements LootItemCondition {
   public static final Codec<MatchTool> f_290941_ = RecordCodecBuilder.create((p_297207_) -> {
      return p_297207_.group(ExtraCodecs.m_294263_(ItemPredicate.f_291722_, "predicate").forGetter(MatchTool::f_81993_)).apply(p_297207_, MatchTool::new);
   });

   public LootItemConditionType m_7940_() {
      return LootItemConditions.f_81819_;
   }

   public Set<LootContextParam<?>> m_6231_() {
      return ImmutableSet.of(LootContextParams.f_81463_);
   }

   public boolean test(LootContext p_82000_) {
      ItemStack itemstack = p_82000_.m_78953_(LootContextParams.f_81463_);
      return itemstack != null && (this.f_81993_.isEmpty() || this.f_81993_.get().m_45049_(itemstack));
   }

   public static LootItemCondition.Builder m_81997_(ItemPredicate.Builder p_81998_) {
      return () -> {
         return new MatchTool(Optional.of(p_81998_.m_45077_()));
      };
   }
}