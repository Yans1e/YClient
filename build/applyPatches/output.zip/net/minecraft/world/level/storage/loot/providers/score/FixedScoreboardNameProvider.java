package net.minecraft.world.level.storage.loot.providers.score;

import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParam;

public record FixedScoreboardNameProvider(String f_165840_) implements ScoreboardNameProvider {
   public static final Codec<FixedScoreboardNameProvider> f_290562_ = RecordCodecBuilder.create((p_300953_) -> {
      return p_300953_.group(Codec.STRING.fieldOf("name").forGetter(FixedScoreboardNameProvider::f_165840_)).apply(p_300953_, FixedScoreboardNameProvider::new);
   });

   public static ScoreboardNameProvider m_165846_(String p_165847_) {
      return new FixedScoreboardNameProvider(p_165847_);
   }

   public LootScoreProviderType m_142680_() {
      return ScoreboardNameProviders.f_165868_;
   }

   @Nullable
   public String m_142600_(LootContext p_165845_) {
      return this.f_165840_;
   }

   public Set<LootContextParam<?>> m_142636_() {
      return ImmutableSet.of();
   }
}