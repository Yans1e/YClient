package net.minecraft.world.level.storage.loot.functions;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Instrument;
import net.minecraft.world.item.InstrumentItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;

public class SetInstrumentFunction extends LootItemConditionalFunction {
   public static final Codec<SetInstrumentFunction> f_290736_ = RecordCodecBuilder.create((p_297135_) -> {
      return m_294820_(p_297135_).and(TagKey.m_203886_(Registries.f_257010_).fieldOf("options").forGetter((p_297134_) -> {
         return p_297134_.f_231006_;
      })).apply(p_297135_, SetInstrumentFunction::new);
   });
   private final TagKey<Instrument> f_231006_;

   private SetInstrumentFunction(List<LootItemCondition> p_297631_, TagKey<Instrument> p_231009_) {
      super(p_297631_);
      this.f_231006_ = p_231009_;
   }

   public LootItemFunctionType m_7162_() {
      return LootItemFunctions.f_230994_;
   }

   public ItemStack m_7372_(ItemStack p_231017_, LootContext p_231018_) {
      InstrumentItem.m_220110_(p_231017_, this.f_231006_, p_231018_.m_230907_());
      return p_231017_;
   }

   public static LootItemConditionalFunction.Builder<?> m_231011_(TagKey<Instrument> p_231012_) {
      return m_80683_((p_297137_) -> {
         return new SetInstrumentFunction(p_297137_, p_231012_);
      });
   }
}