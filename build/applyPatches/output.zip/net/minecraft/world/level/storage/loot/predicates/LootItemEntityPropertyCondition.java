package net.minecraft.world.level.storage.loot.predicates;

import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import java.util.Set;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParam;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;

public record LootItemEntityPropertyCondition(Optional<EntityPredicate> f_81846_, LootContext.EntityTarget f_81847_) implements LootItemCondition {
   public static final Codec<LootItemEntityPropertyCondition> f_291269_ = RecordCodecBuilder.create((p_297203_) -> {
      return p_297203_.group(ExtraCodecs.m_294263_(EntityPredicate.f_291089_, "predicate").forGetter(LootItemEntityPropertyCondition::f_81846_), LootContext.EntityTarget.f_291271_.fieldOf("entity").forGetter(LootItemEntityPropertyCondition::f_81847_)).apply(p_297203_, LootItemEntityPropertyCondition::new);
   });

   public LootItemConditionType m_7940_() {
      return LootItemConditions.f_81815_;
   }

   public Set<LootContextParam<?>> m_6231_() {
      return ImmutableSet.of(LootContextParams.f_81460_, this.f_81847_.m_79003_());
   }

   public boolean test(LootContext p_81871_) {
      Entity entity = p_81871_.m_78953_(this.f_81847_.m_79003_());
      Vec3 vec3 = p_81871_.m_78953_(LootContextParams.f_81460_);
      return this.f_81846_.isEmpty() || this.f_81846_.get().m_36607_(p_81871_.m_78952_(), vec3, entity);
   }

   public static LootItemCondition.Builder m_81862_(LootContext.EntityTarget p_81863_) {
      return m_81864_(p_81863_, EntityPredicate.Builder.m_36633_());
   }

   public static LootItemCondition.Builder m_81864_(LootContext.EntityTarget p_81865_, EntityPredicate.Builder p_81866_) {
      return () -> {
         return new LootItemEntityPropertyCondition(Optional.of(p_81866_.m_36662_()), p_81865_);
      };
   }

   public static LootItemCondition.Builder m_81867_(LootContext.EntityTarget p_81868_, EntityPredicate p_81869_) {
      return () -> {
         return new LootItemEntityPropertyCondition(Optional.of(p_81869_), p_81868_);
      };
   }
}