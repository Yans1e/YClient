package net.minecraft.world.level.levelgen.structure.pieces;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

@FunctionalInterface
public interface PieceGeneratorSupplier<C extends FeatureConfiguration> {
   Optional<PieceGenerator<C>> m_197347_(PieceGeneratorSupplier.Context<C> p_197348_);

   static <C extends FeatureConfiguration> PieceGeneratorSupplier<C> m_197349_(Predicate<PieceGeneratorSupplier.Context<C>> p_197350_, PieceGenerator<C> p_197351_) {
      Optional<PieceGenerator<C>> optional = Optional.of(p_197351_);
      return (p_197344_) -> {
         return p_197350_.test(p_197344_) ? optional : Optional.empty();
      };
   }

   static <C extends FeatureConfiguration> Predicate<PieceGeneratorSupplier.Context<C>> m_197345_(Heightmap.Types p_197346_) {
      return (p_197340_) -> {
         return p_197340_.m_197380_(p_197346_);
      };
   }

   public static record Context<C extends FeatureConfiguration>(ChunkGenerator f_197352_, BiomeSource f_197353_, RandomState f_226941_, long f_197354_, ChunkPos f_197355_, C f_197356_, LevelHeightAccessor f_197357_, Predicate<Holder<Biome>> f_197358_, StructureTemplateManager f_226942_, RegistryAccess f_197360_) {
      public boolean m_197380_(Heightmap.Types p_197381_) {
         int i = this.f_197355_.m_151390_();
         int j = this.f_197355_.m_151393_();
         int k = this.f_197352_.m_223235_(i, j, p_197381_, this.f_197357_, this.f_226941_);
         Holder<Biome> holder = this.f_197352_.m_62218_().m_203407_(QuartPos.m_175400_(i), QuartPos.m_175400_(k), QuartPos.m_175400_(j), this.f_226941_.m_224579_());
         return this.f_197358_.test(holder);
      }
   }
}