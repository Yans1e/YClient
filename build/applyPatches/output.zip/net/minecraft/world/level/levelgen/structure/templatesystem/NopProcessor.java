package net.minecraft.world.level.levelgen.structure.templatesystem;

import com.mojang.serialization.Codec;

public class NopProcessor extends StructureProcessor {
   public static final Codec<NopProcessor> f_74174_ = Codec.unit(() -> {
      return NopProcessor.f_74175_;
   });
   public static final NopProcessor f_74175_ = new NopProcessor();

   private NopProcessor() {
   }

   protected StructureProcessorType<?> m_6953_() {
      return StructureProcessorType.f_74461_;
   }
}