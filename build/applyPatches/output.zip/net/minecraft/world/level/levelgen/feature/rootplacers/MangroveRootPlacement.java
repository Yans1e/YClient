package net.minecraft.world.level.levelgen.feature.rootplacers;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.RegistryCodecs;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;

public record MangroveRootPlacement(HolderSet<Block> f_225773_, HolderSet<Block> f_225774_, BlockStateProvider f_225775_, int f_225776_, int f_225777_, float f_225778_) {
   public static final Codec<MangroveRootPlacement> f_225772_ = RecordCodecBuilder.create((p_225789_) -> {
      return p_225789_.group(RegistryCodecs.m_206277_(Registries.f_256747_).fieldOf("can_grow_through").forGetter((p_225808_) -> {
         return p_225808_.f_225773_;
      }), RegistryCodecs.m_206277_(Registries.f_256747_).fieldOf("muddy_roots_in").forGetter((p_225803_) -> {
         return p_225803_.f_225774_;
      }), BlockStateProvider.f_68747_.fieldOf("muddy_roots_provider").forGetter((p_225800_) -> {
         return p_225800_.f_225775_;
      }), Codec.intRange(1, 12).fieldOf("max_root_width").forGetter((p_225797_) -> {
         return p_225797_.f_225776_;
      }), Codec.intRange(1, 64).fieldOf("max_root_length").forGetter((p_225794_) -> {
         return p_225794_.f_225777_;
      }), Codec.floatRange(0.0F, 1.0F).fieldOf("random_skew_chance").forGetter((p_225791_) -> {
         return p_225791_.f_225778_;
      })).apply(p_225789_, MangroveRootPlacement::new);
   });
}