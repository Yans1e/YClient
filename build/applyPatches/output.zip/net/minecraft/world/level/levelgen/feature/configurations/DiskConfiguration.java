package net.minecraft.world.level.levelgen.feature.configurations;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
import net.minecraft.world.level.levelgen.feature.stateproviders.RuleBasedBlockStateProvider;

public record DiskConfiguration(RuleBasedBlockStateProvider f_225372_, BlockPredicate f_225373_, IntProvider f_67620_, int f_67621_) implements FeatureConfiguration {
   public static final Codec<DiskConfiguration> f_67618_ = RecordCodecBuilder.create((p_191250_) -> {
      return p_191250_.group(RuleBasedBlockStateProvider.f_225924_.fieldOf("state_provider").forGetter(DiskConfiguration::f_225372_), BlockPredicate.f_190392_.fieldOf("target").forGetter(DiskConfiguration::f_225373_), IntProvider.m_146545_(0, 8).fieldOf("radius").forGetter(DiskConfiguration::f_67620_), Codec.intRange(0, 4).fieldOf("half_height").forGetter(DiskConfiguration::f_67621_)).apply(p_191250_, DiskConfiguration::new);
   });
}