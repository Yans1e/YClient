package net.minecraft.stats;

import com.google.common.collect.Sets;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.RecipeBookMenu;
import net.minecraft.world.inventory.RecipeBookType;
import net.minecraft.world.item.crafting.RecipeHolder;

public class RecipeBook {
   protected final Set<ResourceLocation> f_12680_ = Sets.newHashSet();
   protected final Set<ResourceLocation> f_12681_ = Sets.newHashSet();
   private final RecipeBookSettings f_12682_ = new RecipeBookSettings();

   public void m_12685_(RecipeBook p_12686_) {
      this.f_12680_.clear();
      this.f_12681_.clear();
      this.f_12682_.m_12732_(p_12686_.f_12682_);
      this.f_12680_.addAll(p_12686_.f_12680_);
      this.f_12681_.addAll(p_12686_.f_12681_);
   }

   public void m_12700_(RecipeHolder<?> p_301033_) {
      if (!p_301033_.f_291008_().m_5598_()) {
         this.m_12702_(p_301033_.f_291676_());
      }

   }

   protected void m_12702_(ResourceLocation p_12703_) {
      this.f_12680_.add(p_12703_);
   }

   public boolean m_12709_(@Nullable RecipeHolder<?> p_298018_) {
      return p_298018_ == null ? false : this.f_12680_.contains(p_298018_.f_291676_());
   }

   public boolean m_12711_(ResourceLocation p_12712_) {
      return this.f_12680_.contains(p_12712_);
   }

   public void m_12713_(RecipeHolder<?> p_301343_) {
      this.m_12715_(p_301343_.f_291676_());
   }

   protected void m_12715_(ResourceLocation p_12716_) {
      this.f_12680_.remove(p_12716_);
      this.f_12681_.remove(p_12716_);
   }

   public boolean m_12717_(RecipeHolder<?> p_300661_) {
      return this.f_12681_.contains(p_300661_.f_291676_());
   }

   public void m_12721_(RecipeHolder<?> p_298729_) {
      this.f_12681_.remove(p_298729_.f_291676_());
   }

   public void m_12723_(RecipeHolder<?> p_300059_) {
      this.m_12719_(p_300059_.f_291676_());
   }

   protected void m_12719_(ResourceLocation p_12720_) {
      this.f_12681_.add(p_12720_);
   }

   public boolean m_12691_(RecipeBookType p_12692_) {
      return this.f_12682_.m_12734_(p_12692_);
   }

   public void m_12693_(RecipeBookType p_12694_, boolean p_12695_) {
      this.f_12682_.m_12736_(p_12694_, p_12695_);
   }

   public boolean m_12689_(RecipeBookMenu<?> p_12690_) {
      return this.m_12704_(p_12690_.m_5867_());
   }

   public boolean m_12704_(RecipeBookType p_12705_) {
      return this.f_12682_.m_12754_(p_12705_);
   }

   public void m_12706_(RecipeBookType p_12707_, boolean p_12708_) {
      this.f_12682_.m_12756_(p_12707_, p_12708_);
   }

   public void m_12687_(RecipeBookSettings p_12688_) {
      this.f_12682_.m_12732_(p_12688_);
   }

   public RecipeBookSettings m_12684_() {
      return this.f_12682_.m_12731_();
   }

   public void m_12696_(RecipeBookType p_12697_, boolean p_12698_, boolean p_12699_) {
      this.f_12682_.m_12736_(p_12697_, p_12698_);
      this.f_12682_.m_12756_(p_12697_, p_12699_);
   }
}