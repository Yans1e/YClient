package net.minecraft.server.network;

import java.util.function.Consumer;
import net.minecraft.network.protocol.Packet;

public interface ConfigurationTask {
   void m_293075_(Consumer<Packet<?>> p_299398_);

   ConfigurationTask.Type m_293172_();

   public static record Type(String f_290885_) {
      public String toString() {
         return this.f_290885_;
      }
   }
}