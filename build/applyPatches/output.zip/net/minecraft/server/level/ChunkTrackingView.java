package net.minecraft.server.level;

import com.google.common.annotations.VisibleForTesting;
import java.util.function.Consumer;
import net.minecraft.world.level.ChunkPos;

public interface ChunkTrackingView {
   ChunkTrackingView f_290823_ = new ChunkTrackingView() {
      public boolean m_293955_(int p_298894_, int p_300849_, boolean p_299623_) {
         return false;
      }

      public void m_292843_(Consumer<ChunkPos> p_298868_) {
      }
   };

   static ChunkTrackingView m_294585_(ChunkPos p_299839_, int p_298969_) {
      return new ChunkTrackingView.Positioned(p_299839_, p_298969_);
   }

   static void m_293383_(ChunkTrackingView p_297320_, ChunkTrackingView p_298920_, Consumer<ChunkPos> p_300281_, Consumer<ChunkPos> p_298429_) {
      if (!p_297320_.equals(p_298920_)) {
         if (p_297320_ instanceof ChunkTrackingView.Positioned) {
            ChunkTrackingView.Positioned chunktrackingview$positioned = (ChunkTrackingView.Positioned)p_297320_;
            if (p_298920_ instanceof ChunkTrackingView.Positioned) {
               ChunkTrackingView.Positioned chunktrackingview$positioned1 = (ChunkTrackingView.Positioned)p_298920_;
               if (chunktrackingview$positioned.m_294954_(chunktrackingview$positioned1)) {
                  int i = Math.min(chunktrackingview$positioned.m_292933_(), chunktrackingview$positioned1.m_292933_());
                  int j = Math.min(chunktrackingview$positioned.m_294568_(), chunktrackingview$positioned1.m_294568_());
                  int k = Math.max(chunktrackingview$positioned.m_293927_(), chunktrackingview$positioned1.m_293927_());
                  int l = Math.max(chunktrackingview$positioned.m_295008_(), chunktrackingview$positioned1.m_295008_());

                  for(int i1 = i; i1 <= k; ++i1) {
                     for(int j1 = j; j1 <= l; ++j1) {
                        boolean flag = chunktrackingview$positioned.m_294219_(i1, j1);
                        boolean flag1 = chunktrackingview$positioned1.m_294219_(i1, j1);
                        if (flag != flag1) {
                           if (flag1) {
                              p_300281_.accept(new ChunkPos(i1, j1));
                           } else {
                              p_298429_.accept(new ChunkPos(i1, j1));
                           }
                        }
                     }
                  }

                  return;
               }
            }
         }

         p_297320_.m_292843_(p_298429_);
         p_298920_.m_292843_(p_300281_);
      }
   }

   default boolean m_293959_(ChunkPos p_298506_) {
      return this.m_294219_(p_298506_.f_45578_, p_298506_.f_45579_);
   }

   default boolean m_294219_(int p_298205_, int p_299033_) {
      return this.m_293955_(p_298205_, p_299033_, true);
   }

   boolean m_293955_(int p_297637_, int p_299915_, boolean p_300628_);

   void m_292843_(Consumer<ChunkPos> p_301208_);

   default boolean m_292815_(int p_299368_, int p_297466_) {
      return this.m_293955_(p_299368_, p_297466_, false);
   }

   static boolean m_294571_(int p_300363_, int p_300565_, int p_297699_, int p_299801_, int p_300142_) {
      return m_294896_(p_300363_, p_300565_, p_297699_, p_299801_, p_300142_, false);
   }

   static boolean m_294896_(int p_299483_, int p_297415_, int p_300799_, int p_299157_, int p_301327_, boolean p_301271_) {
      int i = Math.max(0, Math.abs(p_299157_ - p_299483_) - 1);
      int j = Math.max(0, Math.abs(p_301327_ - p_297415_) - 1);
      long k = (long)Math.max(0, Math.max(i, j) - (p_301271_ ? 1 : 0));
      long l = (long)Math.min(i, j);
      long i1 = l * l + k * k;
      int j1 = p_300799_ * p_300799_;
      return i1 < (long)j1;
   }

   public static record Positioned(ChunkPos f_290448_, int f_290668_) implements ChunkTrackingView {
      int m_292933_() {
         return this.f_290448_.f_45578_ - this.f_290668_ - 1;
      }

      int m_294568_() {
         return this.f_290448_.f_45579_ - this.f_290668_ - 1;
      }

      int m_293927_() {
         return this.f_290448_.f_45578_ + this.f_290668_ + 1;
      }

      int m_295008_() {
         return this.f_290448_.f_45579_ + this.f_290668_ + 1;
      }

      @VisibleForTesting
      protected boolean m_294954_(ChunkTrackingView.Positioned p_300776_) {
         return this.m_292933_() <= p_300776_.m_293927_() && this.m_293927_() >= p_300776_.m_292933_() && this.m_294568_() <= p_300776_.m_295008_() && this.m_295008_() >= p_300776_.m_294568_();
      }

      public boolean m_293955_(int p_297345_, int p_300837_, boolean p_298477_) {
         return ChunkTrackingView.m_294896_(this.f_290448_.f_45578_, this.f_290448_.f_45579_, this.f_290668_, p_297345_, p_300837_, p_298477_);
      }

      public void m_292843_(Consumer<ChunkPos> p_299048_) {
         for(int i = this.m_292933_(); i <= this.m_293927_(); ++i) {
            for(int j = this.m_294568_(); j <= this.m_295008_(); ++j) {
               if (this.m_294219_(i, j)) {
                  p_299048_.accept(new ChunkPos(i, j));
               }
            }
         }

      }
   }
}