package net.minecraft.client.gui.components.toasts;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RecipeToast implements Toast {
   private static final ResourceLocation f_291662_ = new ResourceLocation("toast/recipe");
   private static final long f_169076_ = 5000L;
   private static final Component f_94803_ = Component.m_237115_("recipe.toast.title");
   private static final Component f_94804_ = Component.m_237115_("recipe.toast.description");
   private final List<RecipeHolder<?>> f_94805_ = Lists.newArrayList();
   private long f_94806_;
   private boolean f_94807_;

   public RecipeToast(RecipeHolder<?> p_300901_) {
      this.f_94805_.add(p_300901_);
   }

   public Toast.Visibility m_7172_(GuiGraphics p_281667_, ToastComponent p_281321_, long p_281779_) {
      if (this.f_94807_) {
         this.f_94806_ = p_281779_;
         this.f_94807_ = false;
      }

      if (this.f_94805_.isEmpty()) {
         return Toast.Visibility.HIDE;
      } else {
         p_281667_.m_292816_(f_291662_, 0, 0, this.m_7828_(), this.m_94899_());
         p_281667_.m_280614_(p_281321_.m_94929_().f_91062_, f_94803_, 30, 7, -11534256, false);
         p_281667_.m_280614_(p_281321_.m_94929_().f_91062_, f_94804_, 30, 18, -16777216, false);
         RecipeHolder<?> recipeholder = this.f_94805_.get((int)((double)p_281779_ / Math.max(1.0D, 5000.0D * p_281321_.m_264542_() / (double)this.f_94805_.size()) % (double)this.f_94805_.size()));
         ItemStack itemstack = recipeholder.f_291008_().m_8042_();
         p_281667_.m_280168_().m_85836_();
         p_281667_.m_280168_().m_85841_(0.6F, 0.6F, 1.0F);
         p_281667_.m_280203_(itemstack, 3, 3);
         p_281667_.m_280168_().m_85849_();
         p_281667_.m_280203_(recipeholder.f_291008_().m_8043_(p_281321_.m_94929_().f_91073_.m_9598_()), 8, 8);
         return (double)(p_281779_ - this.f_94806_) >= 5000.0D * p_281321_.m_264542_() ? Toast.Visibility.HIDE : Toast.Visibility.SHOW;
      }
   }

   private void m_94811_(RecipeHolder<?> p_297895_) {
      this.f_94805_.add(p_297895_);
      this.f_94807_ = true;
   }

   public static void m_94817_(ToastComponent p_94818_, RecipeHolder<?> p_300003_) {
      RecipeToast recipetoast = p_94818_.m_94926_(RecipeToast.class, f_94894_);
      if (recipetoast == null) {
         p_94818_.m_94922_(new RecipeToast(p_300003_));
      } else {
         recipetoast.m_94811_(p_300003_);
      }

   }
}