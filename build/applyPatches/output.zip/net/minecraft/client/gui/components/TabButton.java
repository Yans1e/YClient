package net.minecraft.client.gui.components;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.tabs.Tab;
import net.minecraft.client.gui.components.tabs.TabManager;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class TabButton extends AbstractWidget {
   private static final WidgetSprites f_291157_ = new WidgetSprites(new ResourceLocation("widget/tab_selected"), new ResourceLocation("widget/tab"), new ResourceLocation("widget/tab_selected_highlighted"), new ResourceLocation("widget/tab_highlighted"));
   private static final int f_273861_ = 3;
   private static final int f_273873_ = 1;
   private static final int f_273895_ = 1;
   private static final int f_273921_ = 4;
   private static final int f_273844_ = 2;
   private final TabManager f_273884_;
   private final Tab f_273837_;

   public TabButton(TabManager p_275399_, Tab p_275391_, int p_275340_, int p_275364_) {
      super(0, 0, p_275340_, p_275364_, p_275391_.m_267600_());
      this.f_273884_ = p_275399_;
      this.f_273837_ = p_275391_;
   }

   public void m_87963_(GuiGraphics p_283350_, int p_283437_, int p_281595_, float p_282117_) {
      p_283350_.m_292816_(f_291157_.m_295557_(this.m_274319_(), this.m_274382_()), this.m_252754_(), this.m_252907_(), this.f_93618_, this.f_93619_);
      Font font = Minecraft.m_91087_().f_91062_;
      int i = this.f_93623_ ? -1 : -6250336;
      this.m_274488_(p_283350_, font, i);
      if (this.m_274319_()) {
         this.m_274365_(p_283350_, font, i);
      }

   }

   public void m_274488_(GuiGraphics p_282917_, Font p_275208_, int p_275293_) {
      int i = this.m_252754_() + 1;
      int j = this.m_252907_() + (this.m_274319_() ? 0 : 3);
      int k = this.m_252754_() + this.m_5711_() - 1;
      int l = this.m_252907_() + this.m_93694_();
      m_280138_(p_282917_, p_275208_, this.m_6035_(), i, j, k, l, p_275293_);
   }

   private void m_274365_(GuiGraphics p_282383_, Font p_275475_, int p_275367_) {
      int i = Math.min(p_275475_.m_92852_(this.m_6035_()), this.m_5711_() - 4);
      int j = this.m_252754_() + (this.m_5711_() - i) / 2;
      int k = this.m_252907_() + this.m_93694_() - 2;
      p_282383_.m_280509_(j, k, j + i, k + 1, p_275367_);
   }

   protected void m_168797_(NarrationElementOutput p_275465_) {
      p_275465_.m_169146_(NarratedElementType.TITLE, Component.m_237110_("gui.narrate.tab", this.f_273837_.m_267600_()));
   }

   public void m_7435_(SoundManager p_276302_) {
   }

   public Tab m_274356_() {
      return this.f_273837_;
   }

   public boolean m_274319_() {
      return this.f_273884_.m_267695_() == this.f_273837_;
   }
}