package net.minecraft.client.gui.screens.reporting;

import com.mojang.authlib.minecraft.report.AbuseReportLimits;
import com.mojang.logging.LogUtils;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.screens.GenericWaitingScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.WarningScreen;
import net.minecraft.client.multiplayer.chat.report.Report;
import net.minecraft.client.multiplayer.chat.report.ReportingContext;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ThrowingComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public abstract class AbstractReportScreen<B extends Report.Builder<?>> extends Screen {
   private static final Component f_290425_ = Component.m_237115_("gui.abuseReport.report_sent_msg");
   private static final Component f_290561_ = Component.m_237115_("gui.abuseReport.sending.title").m_130940_(ChatFormatting.BOLD);
   private static final Component f_291522_ = Component.m_237115_("gui.abuseReport.sent.title").m_130940_(ChatFormatting.BOLD);
   private static final Component f_291718_ = Component.m_237115_("gui.abuseReport.error.title").m_130940_(ChatFormatting.BOLD);
   private static final Component f_291276_ = Component.m_237115_("gui.abuseReport.send.generic_error");
   protected static final Component f_291286_ = Component.m_237115_("gui.abuseReport.send");
   protected static final Component f_291897_ = Component.m_237115_("gui.abuseReport.observed_what");
   protected static final Component f_291244_ = Component.m_237115_("gui.abuseReport.select_reason");
   private static final Component f_291006_ = Component.m_237115_("gui.abuseReport.describe");
   protected static final Component f_291159_ = Component.m_237115_("gui.abuseReport.more_comments");
   private static final Component f_290728_ = Component.m_237115_("gui.abuseReport.comments");
   protected static final int f_290645_ = 20;
   protected static final int f_291307_ = 280;
   protected static final int f_291753_ = 8;
   private static final Logger f_290331_ = LogUtils.getLogger();
   protected final Screen f_290903_;
   protected final ReportingContext f_291860_;
   protected B f_291568_;

   protected AbstractReportScreen(Component p_297559_, Screen p_299592_, ReportingContext p_300174_, B p_300351_) {
      super(p_297559_);
      this.f_290903_ = p_299592_;
      this.f_291860_ = p_300174_;
      this.f_291568_ = p_300351_;
   }

   protected MultiLineEditBox m_294932_(int p_297252_, int p_301025_, Consumer<String> p_298469_) {
      AbuseReportLimits abusereportlimits = this.f_291860_.m_240161_().m_239479_();
      MultiLineEditBox multilineeditbox = new MultiLineEditBox(this.f_96547_, 0, 0, p_297252_, p_301025_, f_291006_, f_290728_);
      multilineeditbox.m_240159_(this.f_291568_.m_295576_());
      multilineeditbox.m_239313_(abusereportlimits.maxOpinionCommentsLength());
      multilineeditbox.m_239273_(p_298469_);
      return multilineeditbox;
   }

   protected void m_293734_() {
      this.f_291568_.m_292692_(this.f_291860_).ifLeft((p_301124_) -> {
         CompletableFuture<?> completablefuture = this.f_291860_.m_240161_().m_239469_(p_301124_.f_291826_(), p_301124_.f_290853_(), p_301124_.f_291496_());
         this.f_96541_.m_91152_(GenericWaitingScreen.m_240309_(f_290561_, CommonComponents.f_130656_, () -> {
            this.f_96541_.m_91152_(this);
            completablefuture.cancel(true);
         }));
         completablefuture.handleAsync((p_301251_, p_299485_) -> {
            if (p_299485_ == null) {
               this.m_294438_();
            } else {
               if (p_299485_ instanceof CancellationException) {
                  return null;
               }

               this.m_294591_(p_299485_);
            }

            return null;
         }, this.f_96541_);
      }).ifRight((p_298848_) -> {
         this.m_295157_(p_298848_.f_290450_());
      });
   }

   private void m_294438_() {
      this.m_294948_();
      this.f_96541_.m_91152_(GenericWaitingScreen.m_240290_(f_291522_, f_290425_, CommonComponents.f_130655_, () -> {
         this.f_96541_.m_91152_((Screen)null);
      }));
   }

   private void m_294591_(Throwable p_297880_) {
      f_290331_.error("Encountered error while sending abuse report", p_297880_);
      Throwable throwable = p_297880_.getCause();
      Component component;
      if (throwable instanceof ThrowingComponent throwingcomponent) {
         component = throwingcomponent.m_237308_();
      } else {
         component = f_291276_;
      }

      this.m_295157_(component);
   }

   private void m_295157_(Component p_301245_) {
      Component component = p_301245_.m_6881_().m_130940_(ChatFormatting.RED);
      this.f_96541_.m_91152_(GenericWaitingScreen.m_240290_(f_291718_, component, CommonComponents.f_130660_, () -> {
         this.f_96541_.m_91152_(this);
      }));
   }

   void m_295806_() {
      if (this.f_291568_.m_293281_()) {
         this.f_291860_.m_293837_(this.f_291568_.m_292899_().m_292702_());
      }

   }

   void m_294948_() {
      this.f_291860_.m_293837_((Report)null);
   }

   public void m_7379_() {
      if (this.f_291568_.m_293281_()) {
         this.f_96541_.m_91152_(new AbstractReportScreen.DiscardReportWarningScreen());
      } else {
         this.f_96541_.m_91152_(this.f_290903_);
      }

   }

   public void m_7861_() {
      this.m_295806_();
      super.m_7861_();
   }

   @OnlyIn(Dist.CLIENT)
   class DiscardReportWarningScreen extends WarningScreen {
      private static final int f_291284_ = 20;
      private static final Component f_290974_ = Component.m_237115_("gui.abuseReport.discard.title").m_130940_(ChatFormatting.BOLD);
      private static final Component f_291630_ = Component.m_237115_("gui.abuseReport.discard.content");
      private static final Component f_291173_ = Component.m_237115_("gui.abuseReport.discard.return");
      private static final Component f_290633_ = Component.m_237115_("gui.abuseReport.discard.draft");
      private static final Component f_290521_ = Component.m_237115_("gui.abuseReport.discard.discard");

      protected DiscardReportWarningScreen() {
         super(f_290974_, f_291630_, f_291630_);
      }

      protected void m_207212_(int p_300335_) {
         this.m_142416_(Button.m_253074_(f_291173_, (p_299113_) -> {
            this.m_7379_();
         }).m_252794_(this.f_96543_ / 2 - 155, 100 + p_300335_).m_253136_());
         this.m_142416_(Button.m_253074_(f_290633_, (p_301082_) -> {
            AbstractReportScreen.this.m_295806_();
            this.f_96541_.m_91152_(AbstractReportScreen.this.f_290903_);
         }).m_252794_(this.f_96543_ / 2 + 5, 100 + p_300335_).m_253136_());
         this.m_142416_(Button.m_253074_(f_290521_, (p_299406_) -> {
            AbstractReportScreen.this.m_294948_();
            this.f_96541_.m_91152_(AbstractReportScreen.this.f_290903_);
         }).m_252794_(this.f_96543_ / 2 - 75, 130 + p_300335_).m_253136_());
      }

      public void m_7379_() {
         this.f_96541_.m_91152_(AbstractReportScreen.this);
      }

      public boolean m_6913_() {
         return false;
      }

      protected void m_280583_(GuiGraphics p_299952_) {
         p_299952_.m_280430_(this.f_96547_, this.f_96539_, this.f_96543_ / 2 - 155, 30, -1);
      }
   }
}