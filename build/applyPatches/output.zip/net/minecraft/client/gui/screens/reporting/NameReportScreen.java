package net.minecraft.client.gui.screens.reporting;

import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.Optionull;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.CommonLayouts;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.chat.report.NameReport;
import net.minecraft.client.multiplayer.chat.report.Report;
import net.minecraft.client.multiplayer.chat.report.ReportingContext;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class NameReportScreen extends AbstractReportScreen<NameReport.Builder> {
   private static final int f_290998_ = 120;
   private static final Component f_290359_ = Component.m_237115_("gui.abuseReport.name.title");
   private final LinearLayout f_291846_ = LinearLayout.m_293633_().m_294554_(8);
   private MultiLineEditBox f_290978_;
   private Button f_291903_;

   private NameReportScreen(Screen p_300534_, ReportingContext p_300915_, NameReport.Builder p_300014_) {
      super(f_290359_, p_300534_, p_300915_, p_300014_);
   }

   public NameReportScreen(Screen p_300152_, ReportingContext p_300083_, UUID p_298096_, String p_300249_) {
      this(p_300152_, p_300083_, new NameReport.Builder(p_298096_, p_300249_, p_300083_.m_240161_().m_239479_()));
   }

   public NameReportScreen(Screen p_300445_, ReportingContext p_299367_, NameReport p_297896_) {
      this(p_300445_, p_299367_, new NameReport.Builder(p_297896_, p_299367_.m_240161_().m_239479_()));
   }

   protected void m_7856_() {
      this.f_291846_.m_294823_().m_264356_();
      this.f_291846_.m_264406_(new StringWidget(this.f_96539_, this.f_96547_));
      Component component = Component.m_237113_(this.f_291568_.m_292899_().m_294329_()).m_130940_(ChatFormatting.YELLOW);
      this.f_291846_.m_293842_(new StringWidget(Component.m_237110_("gui.abuseReport.name.reporting", component), this.f_96547_), (p_297722_) -> {
         p_297722_.m_264463_().m_264414_(0, 8);
      });
      this.f_290978_ = this.m_294932_(280, 9 * 8, (p_299894_) -> {
         this.f_291568_.m_293258_(p_299894_);
         this.m_294828_();
      });
      this.f_291846_.m_264406_(CommonLayouts.m_293132_(this.f_96547_, this.f_290978_, f_291159_, (p_299823_) -> {
         p_299823_.m_264154_(12);
      }));
      LinearLayout linearlayout = this.f_291846_.m_264406_(LinearLayout.m_295847_().m_294554_(8));
      linearlayout.m_264406_(Button.m_253074_(CommonComponents.f_130660_, (p_298578_) -> {
         this.m_7379_();
      }).m_252780_(120).m_253136_());
      this.f_291903_ = linearlayout.m_264406_(Button.m_253074_(f_291286_, (p_299575_) -> {
         this.m_293734_();
      }).m_252780_(120).m_253136_());
      this.m_294828_();
      this.f_291846_.m_264134_((p_297689_) -> {
         AbstractWidget abstractwidget = this.m_142416_(p_297689_);
      });
      this.m_267719_();
   }

   protected void m_267719_() {
      this.f_291846_.m_264036_();
      FrameLayout.m_267781_(this.f_291846_, this.m_264198_());
   }

   private void m_294828_() {
      Report.CannotBuildReason report$cannotbuildreason = this.f_291568_.m_293936_();
      this.f_291903_.f_93623_ = report$cannotbuildreason == null;
      this.f_291903_.m_257544_(Optionull.m_269382_(report$cannotbuildreason, Report.CannotBuildReason::m_293758_));
   }

   public boolean m_6348_(double p_297585_, double p_300170_, int p_297299_) {
      return super.m_6348_(p_297585_, p_300170_, p_297299_) ? true : this.f_290978_.m_6348_(p_297585_, p_300170_, p_297299_);
   }
}