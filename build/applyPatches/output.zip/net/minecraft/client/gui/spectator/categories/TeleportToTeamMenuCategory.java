package net.minecraft.client.gui.spectator.categories;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.spectator.SpectatorMenu;
import net.minecraft.client.gui.spectator.SpectatorMenuCategory;
import net.minecraft.client.gui.spectator.SpectatorMenuItem;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.GameType;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class TeleportToTeamMenuCategory implements SpectatorMenuCategory, SpectatorMenuItem {
   private static final ResourceLocation f_291215_ = new ResourceLocation("spectator/teleport_to_team");
   private static final Component f_101875_ = Component.m_237115_("spectatorMenu.team_teleport");
   private static final Component f_101876_ = Component.m_237115_("spectatorMenu.team_teleport.prompt");
   private final List<SpectatorMenuItem> f_101877_;

   public TeleportToTeamMenuCategory() {
      Minecraft minecraft = Minecraft.m_91087_();
      this.f_101877_ = m_257833_(minecraft, minecraft.f_91073_.m_6188_());
   }

   private static List<SpectatorMenuItem> m_257833_(Minecraft p_260258_, Scoreboard p_259249_) {
      return p_259249_.m_83491_().stream().flatMap((p_260025_) -> {
         return TeleportToTeamMenuCategory.TeamSelectionItem.m_257760_(p_260258_, p_260025_).stream();
      }).toList();
   }

   public List<SpectatorMenuItem> m_5919_() {
      return this.f_101877_;
   }

   public Component m_5878_() {
      return f_101876_;
   }

   public void m_7608_(SpectatorMenu p_101886_) {
      p_101886_.m_101794_(this);
   }

   public Component m_7869_() {
      return f_101875_;
   }

   public void m_6252_(GuiGraphics p_282933_, float p_283568_, int p_281803_) {
      p_282933_.m_292816_(f_291215_, 0, 0, 16, 16);
   }

   public boolean m_7304_() {
      return !this.f_101877_.isEmpty();
   }

   @OnlyIn(Dist.CLIENT)
   static class TeamSelectionItem implements SpectatorMenuItem {
      private final PlayerTeam f_101891_;
      private final Supplier<PlayerSkin> f_256959_;
      private final List<PlayerInfo> f_101893_;

      private TeamSelectionItem(PlayerTeam p_259176_, List<PlayerInfo> p_259231_, Supplier<PlayerSkin> p_300864_) {
         this.f_101891_ = p_259176_;
         this.f_101893_ = p_259231_;
         this.f_256959_ = p_300864_;
      }

      public static Optional<SpectatorMenuItem> m_257760_(Minecraft p_260048_, PlayerTeam p_259058_) {
         List<PlayerInfo> list = new ArrayList<>();

         for(String s : p_259058_.m_6809_()) {
            PlayerInfo playerinfo = p_260048_.m_91403_().m_104938_(s);
            if (playerinfo != null && playerinfo.m_105325_() != GameType.SPECTATOR) {
               list.add(playerinfo);
            }
         }

         if (list.isEmpty()) {
            return Optional.empty();
         } else {
            GameProfile gameprofile = list.get(RandomSource.m_216327_().m_188503_(list.size())).m_105312_();
            Supplier<PlayerSkin> supplier = p_260048_.m_91109_().m_293884_(gameprofile);
            return Optional.of(new TeleportToTeamMenuCategory.TeamSelectionItem(p_259058_, list, supplier));
         }
      }

      public void m_7608_(SpectatorMenu p_101902_) {
         p_101902_.m_101794_(new TeleportToPlayerMenuCategory(this.f_101893_));
      }

      public Component m_7869_() {
         return this.f_101891_.m_83364_();
      }

      public void m_6252_(GuiGraphics p_283215_, float p_282946_, int p_283438_) {
         Integer integer = this.f_101891_.m_7414_().m_126665_();
         if (integer != null) {
            float f = (float)(integer >> 16 & 255) / 255.0F;
            float f1 = (float)(integer >> 8 & 255) / 255.0F;
            float f2 = (float)(integer & 255) / 255.0F;
            p_283215_.m_280509_(1, 1, 15, 15, Mth.m_14159_(f * p_282946_, f1 * p_282946_, f2 * p_282946_) | p_283438_ << 24);
         }

         p_283215_.m_280246_(p_282946_, p_282946_, p_282946_, (float)p_283438_ / 255.0F);
         PlayerFaceRenderer.m_293067_(p_283215_, this.f_256959_.get(), 2, 2, 12);
         p_283215_.m_280246_(1.0F, 1.0F, 1.0F, 1.0F);
      }

      public boolean m_7304_() {
         return true;
      }
   }
}