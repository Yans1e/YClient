package net.minecraft.client.telemetry.events;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.telemetry.TelemetryEventSender;
import net.minecraft.client.telemetry.TelemetryEventType;
import net.minecraft.client.telemetry.TelemetryProperty;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class PerformanceMetricsEvent extends AggregatedTelemetryEvent {
   private static final long f_260536_ = m_261284_(Runtime.getRuntime().maxMemory());
   private final LongList f_260632_ = new LongArrayList();
   private final LongList f_260487_ = new LongArrayList();
   private final LongList f_260646_ = new LongArrayList();

   public void m_263206_(TelemetryEventSender p_263321_) {
      if (Minecraft.m_91087_().m_260979_()) {
         super.m_263206_(p_263321_);
      }

   }

   private void m_260818_() {
      this.f_260632_.clear();
      this.f_260487_.clear();
      this.f_260646_.clear();
   }

   public void m_260835_() {
      this.f_260632_.add((long)Minecraft.m_91087_().m_260875_());
      this.m_261164_();
      this.f_260487_.add(Minecraft.m_91087_().m_261169_());
   }

   private void m_261164_() {
      long i = Runtime.getRuntime().totalMemory();
      long j = Runtime.getRuntime().freeMemory();
      long k = i - j;
      this.f_260646_.add(m_261284_(k));
   }

   public void m_260819_(TelemetryEventSender p_261872_) {
      p_261872_.m_260919_(TelemetryEventType.f_260620_, (p_261568_) -> {
         p_261568_.m_261137_(TelemetryProperty.f_260557_, new LongArrayList(this.f_260632_));
         p_261568_.m_261137_(TelemetryProperty.f_260713_, new LongArrayList(this.f_260487_));
         p_261568_.m_261137_(TelemetryProperty.f_260645_, new LongArrayList(this.f_260646_));
         p_261568_.m_261137_(TelemetryProperty.f_260649_, this.m_261091_());
         p_261568_.m_261137_(TelemetryProperty.f_260683_, Minecraft.m_91087_().f_91066_.m_193772_());
         p_261568_.m_261137_(TelemetryProperty.f_260700_, (int)f_260536_);
      });
      this.m_260818_();
   }

   private static long m_261284_(long p_261471_) {
      return p_261471_ / 1000L;
   }
}