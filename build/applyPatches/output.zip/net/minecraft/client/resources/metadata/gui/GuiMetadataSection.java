package net.minecraft.client.resources.metadata.gui;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.server.packs.metadata.MetadataSectionType;
import net.minecraft.util.ExtraCodecs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public record GuiMetadataSection(GuiSpriteScaling f_290460_) {
   public static final GuiMetadataSection f_291890_ = new GuiMetadataSection(GuiSpriteScaling.f_290434_);
   public static final Codec<GuiMetadataSection> f_291082_ = RecordCodecBuilder.create((p_301140_) -> {
      return p_301140_.group(ExtraCodecs.m_295827_(GuiSpriteScaling.f_291700_, "scaling", GuiSpriteScaling.f_290434_).forGetter(GuiMetadataSection::f_290460_)).apply(p_301140_, GuiMetadataSection::new);
   });
   public static final MetadataSectionType<GuiMetadataSection> f_291044_ = MetadataSectionType.m_245060_("gui", f_291082_);
}