package net.minecraft.client.resources;

import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.client.renderer.texture.SpriteLoader;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.metadata.MetadataSectionSerializer;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class TextureAtlasHolder implements PreparableReloadListener, AutoCloseable {
   private final TextureAtlas f_118884_;
   private final ResourceLocation f_260648_;
   private final Set<MetadataSectionSerializer<?>> f_291391_;

   public TextureAtlasHolder(TextureManager p_262057_, ResourceLocation p_261554_, ResourceLocation p_262147_) {
      this(p_262057_, p_261554_, p_262147_, SpriteLoader.f_291626_);
   }

   public TextureAtlasHolder(TextureManager p_299844_, ResourceLocation p_299366_, ResourceLocation p_297647_, Set<MetadataSectionSerializer<?>> p_298542_) {
      this.f_260648_ = p_297647_;
      this.f_118884_ = new TextureAtlas(p_299366_);
      p_299844_.m_118495_(this.f_118884_.m_118330_(), this.f_118884_);
      this.f_291391_ = p_298542_;
   }

   protected TextureAtlasSprite m_118901_(ResourceLocation p_118902_) {
      return this.f_118884_.m_118316_(p_118902_);
   }

   public final CompletableFuture<Void> m_5540_(PreparableReloadListener.PreparationBarrier p_249641_, ResourceManager p_250036_, ProfilerFiller p_249806_, ProfilerFiller p_250732_, Executor p_249427_, Executor p_250510_) {
      return SpriteLoader.m_245483_(this.f_118884_).m_293475_(p_250036_, this.f_260648_, 0, p_249427_, this.f_291391_).thenCompose(SpriteLoader.Preparations::m_246429_).thenCompose(p_249641_::m_6769_).thenAcceptAsync((p_249246_) -> {
         this.m_245256_(p_249246_, p_250732_);
      }, p_250510_);
   }

   private void m_245256_(SpriteLoader.Preparations p_252333_, ProfilerFiller p_250624_) {
      p_250624_.m_7242_();
      p_250624_.m_6180_("upload");
      this.f_118884_.m_247065_(p_252333_);
      p_250624_.m_7238_();
      p_250624_.m_7241_();
   }

   public void close() {
      this.f_118884_.m_118329_();
   }
}