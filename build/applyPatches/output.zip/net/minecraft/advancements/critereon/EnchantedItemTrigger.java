package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import java.util.Optional;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class EnchantedItemTrigger extends SimpleCriterionTrigger<EnchantedItemTrigger.TriggerInstance> {
   public EnchantedItemTrigger.TriggerInstance m_7214_(JsonObject p_286360_, Optional<ContextAwarePredicate> p_298290_, DeserializationContext p_286441_) {
      Optional<ItemPredicate> optional = ItemPredicate.m_45051_(p_286360_.get("item"));
      MinMaxBounds.Ints minmaxbounds$ints = MinMaxBounds.Ints.m_55373_(p_286360_.get("levels"));
      return new EnchantedItemTrigger.TriggerInstance(p_298290_, optional, minmaxbounds$ints);
   }

   public void m_27668_(ServerPlayer p_27669_, ItemStack p_27670_, int p_27671_) {
      this.m_66234_(p_27669_, (p_27675_) -> {
         return p_27675_.m_27691_(p_27670_, p_27671_);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final Optional<ItemPredicate> f_27685_;
      private final MinMaxBounds.Ints f_27686_;

      public TriggerInstance(Optional<ContextAwarePredicate> p_299804_, Optional<ItemPredicate> p_297635_, MinMaxBounds.Ints p_286367_) {
         super(p_299804_);
         this.f_27685_ = p_297635_;
         this.f_27686_ = p_286367_;
      }

      public static Criterion<EnchantedItemTrigger.TriggerInstance> m_27696_() {
         return CriteriaTriggers.f_10575_.m_292665_(new EnchantedItemTrigger.TriggerInstance(Optional.empty(), Optional.empty(), MinMaxBounds.Ints.f_55364_));
      }

      public boolean m_27691_(ItemStack p_27692_, int p_27693_) {
         if (this.f_27685_.isPresent() && !this.f_27685_.get().m_45049_(p_27692_)) {
            return false;
         } else {
            return this.f_27686_.m_55390_(p_27693_);
         }
      }

      public JsonObject m_7683_() {
         JsonObject jsonobject = super.m_7683_();
         this.f_27685_.ifPresent((p_297307_) -> {
            jsonobject.add("item", p_297307_.m_45048_());
         });
         jsonobject.add("levels", this.f_27686_.m_293276_());
         return jsonobject;
      }
   }
}