package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import java.util.Optional;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public class ShotCrossbowTrigger extends SimpleCriterionTrigger<ShotCrossbowTrigger.TriggerInstance> {
   public ShotCrossbowTrigger.TriggerInstance m_7214_(JsonObject p_286726_, Optional<ContextAwarePredicate> p_300212_, DeserializationContext p_286701_) {
      Optional<ItemPredicate> optional = ItemPredicate.m_45051_(p_286726_.get("item"));
      return new ShotCrossbowTrigger.TriggerInstance(p_300212_, optional);
   }

   public void m_65462_(ServerPlayer p_65463_, ItemStack p_65464_) {
      this.m_66234_(p_65463_, (p_65467_) -> {
         return p_65467_.m_65481_(p_65464_);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final Optional<ItemPredicate> f_65477_;

      public TriggerInstance(Optional<ContextAwarePredicate> p_297452_, Optional<ItemPredicate> p_301333_) {
         super(p_297452_);
         this.f_65477_ = p_301333_;
      }

      public static Criterion<ShotCrossbowTrigger.TriggerInstance> m_159431_(Optional<ItemPredicate> p_299474_) {
         return CriteriaTriggers.f_10555_.m_292665_(new ShotCrossbowTrigger.TriggerInstance(Optional.empty(), p_299474_));
      }

      public static Criterion<ShotCrossbowTrigger.TriggerInstance> m_65483_(ItemLike p_65484_) {
         return CriteriaTriggers.f_10555_.m_292665_(new ShotCrossbowTrigger.TriggerInstance(Optional.empty(), Optional.of(ItemPredicate.Builder.m_45068_().m_151445_(p_65484_).m_45077_())));
      }

      public boolean m_65481_(ItemStack p_65482_) {
         return this.f_65477_.isEmpty() || this.f_65477_.get().m_45049_(p_65482_);
      }

      public JsonObject m_7683_() {
         JsonObject jsonobject = super.m_7683_();
         this.f_65477_.ifPresent((p_298022_) -> {
            jsonobject.add("item", p_298022_.m_45048_());
         });
         return jsonobject;
      }
   }
}