package net.minecraft.advancements.critereon;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.gson.JsonObject;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.storage.loot.LootContext;

public class KilledByCrossbowTrigger extends SimpleCriterionTrigger<KilledByCrossbowTrigger.TriggerInstance> {
   public KilledByCrossbowTrigger.TriggerInstance m_7214_(JsonObject p_286674_, Optional<ContextAwarePredicate> p_299181_, DeserializationContext p_286778_) {
      List<ContextAwarePredicate> list = EntityPredicate.m_285868_(p_286674_, "victims", p_286778_);
      MinMaxBounds.Ints minmaxbounds$ints = MinMaxBounds.Ints.m_55373_(p_286674_.get("unique_entity_types"));
      return new KilledByCrossbowTrigger.TriggerInstance(p_299181_, list, minmaxbounds$ints);
   }

   public void m_46871_(ServerPlayer p_46872_, Collection<Entity> p_46873_) {
      List<LootContext> list = Lists.newArrayList();
      Set<EntityType<?>> set = Sets.newHashSet();

      for(Entity entity : p_46873_) {
         set.add(entity.m_6095_());
         list.add(EntityPredicate.m_36616_(p_46872_, entity));
      }

      this.m_66234_(p_46872_, (p_46881_) -> {
         return p_46881_.m_46897_(list, set.size());
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final List<ContextAwarePredicate> f_46887_;
      private final MinMaxBounds.Ints f_46888_;

      public TriggerInstance(Optional<ContextAwarePredicate> p_297734_, List<ContextAwarePredicate> p_299724_, MinMaxBounds.Ints p_286571_) {
         super(p_297734_);
         this.f_46887_ = p_299724_;
         this.f_46888_ = p_286571_;
      }

      public static Criterion<KilledByCrossbowTrigger.TriggerInstance> m_46900_(EntityPredicate.Builder... p_46901_) {
         return CriteriaTriggers.f_10556_.m_292665_(new KilledByCrossbowTrigger.TriggerInstance(Optional.empty(), EntityPredicate.m_294255_(p_46901_), MinMaxBounds.Ints.f_55364_));
      }

      public static Criterion<KilledByCrossbowTrigger.TriggerInstance> m_46893_(MinMaxBounds.Ints p_46894_) {
         return CriteriaTriggers.f_10556_.m_292665_(new KilledByCrossbowTrigger.TriggerInstance(Optional.empty(), List.of(), p_46894_));
      }

      public boolean m_46897_(Collection<LootContext> p_46898_, int p_46899_) {
         if (!this.f_46887_.isEmpty()) {
            List<LootContext> list = Lists.newArrayList(p_46898_);

            for(ContextAwarePredicate contextawarepredicate : this.f_46887_) {
               boolean flag = false;
               Iterator<LootContext> iterator = list.iterator();

               while(iterator.hasNext()) {
                  LootContext lootcontext = iterator.next();
                  if (contextawarepredicate.m_285831_(lootcontext)) {
                     iterator.remove();
                     flag = true;
                     break;
                  }
               }

               if (!flag) {
                  return false;
               }
            }
         }

         return this.f_46888_.m_55390_(p_46899_);
      }

      public JsonObject m_7683_() {
         JsonObject jsonobject = super.m_7683_();
         jsonobject.add("victims", ContextAwarePredicate.m_285805_(this.f_46887_));
         jsonobject.add("unique_entity_types", this.f_46888_.m_293276_());
         return jsonobject;
      }
   }
}