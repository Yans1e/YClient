package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import java.util.Optional;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class UsingItemTrigger extends SimpleCriterionTrigger<UsingItemTrigger.TriggerInstance> {
   public UsingItemTrigger.TriggerInstance m_7214_(JsonObject p_286642_, Optional<ContextAwarePredicate> p_300027_, DeserializationContext p_286897_) {
      Optional<ItemPredicate> optional = ItemPredicate.m_45051_(p_286642_.get("item"));
      return new UsingItemTrigger.TriggerInstance(p_300027_, optional);
   }

   public void m_163865_(ServerPlayer p_163866_, ItemStack p_163867_) {
      this.m_66234_(p_163866_, (p_163870_) -> {
         return p_163870_.m_163886_(p_163867_);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final Optional<ItemPredicate> f_163879_;

      public TriggerInstance(Optional<ContextAwarePredicate> p_297819_, Optional<ItemPredicate> p_300680_) {
         super(p_297819_);
         this.f_163879_ = p_300680_;
      }

      public static Criterion<UsingItemTrigger.TriggerInstance> m_163883_(EntityPredicate.Builder p_163884_, ItemPredicate.Builder p_163885_) {
         return CriteriaTriggers.f_145090_.m_292665_(new UsingItemTrigger.TriggerInstance(Optional.of(EntityPredicate.m_293222_(p_163884_)), Optional.of(p_163885_.m_45077_())));
      }

      public boolean m_163886_(ItemStack p_163887_) {
         return !this.f_163879_.isPresent() || this.f_163879_.get().m_45049_(p_163887_);
      }

      public JsonObject m_7683_() {
         JsonObject jsonobject = super.m_7683_();
         this.f_163879_.ifPresent((p_300679_) -> {
            jsonobject.add("item", p_300679_.m_45048_());
         });
         return jsonobject;
      }
   }
}