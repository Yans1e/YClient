package net.minecraft.advancements.critereon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collection;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public record BlockPredicate(Optional<TagKey<Block>> f_17903_, Optional<HolderSet<Block>> f_146710_, Optional<StatePropertiesPredicate> f_17905_, Optional<NbtPredicate> f_17906_) {
   private static final Codec<HolderSet<Block>> f_290631_ = BuiltInRegistries.f_256975_.m_206110_().listOf().xmap(HolderSet::m_205800_, (p_296114_) -> {
      return p_296114_.m_203614_().toList();
   });
   public static final Codec<BlockPredicate> f_291811_ = RecordCodecBuilder.create((p_296115_) -> {
      return p_296115_.group(ExtraCodecs.m_294263_(TagKey.m_203877_(Registries.f_256747_), "tag").forGetter(BlockPredicate::f_17903_), ExtraCodecs.m_294263_(f_290631_, "blocks").forGetter(BlockPredicate::f_146710_), ExtraCodecs.m_294263_(StatePropertiesPredicate.f_291190_, "state").forGetter(BlockPredicate::f_17905_), ExtraCodecs.m_294263_(NbtPredicate.f_291854_, "nbt").forGetter(BlockPredicate::f_17906_)).apply(p_296115_, BlockPredicate::new);
   });

   public boolean m_17914_(ServerLevel p_17915_, BlockPos p_17916_) {
      if (!p_17915_.m_46749_(p_17916_)) {
         return false;
      } else {
         BlockState blockstate = p_17915_.m_8055_(p_17916_);
         if (this.f_17903_.isPresent() && !blockstate.m_204336_(this.f_17903_.get())) {
            return false;
         } else if (this.f_146710_.isPresent() && !blockstate.m_204341_(this.f_146710_.get())) {
            return false;
         } else if (this.f_17905_.isPresent() && !this.f_17905_.get().m_67667_(blockstate)) {
            return false;
         } else {
            if (this.f_17906_.isPresent()) {
               BlockEntity blockentity = p_17915_.m_7702_(p_17916_);
               if (blockentity == null || !this.f_17906_.get().m_57483_(blockentity.m_187480_())) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   public static class Builder {
      private Optional<HolderSet<Block>> f_17920_ = Optional.empty();
      private Optional<TagKey<Block>> f_146721_ = Optional.empty();
      private Optional<StatePropertiesPredicate> f_17921_ = Optional.empty();
      private Optional<NbtPredicate> f_17922_ = Optional.empty();

      private Builder() {
      }

      public static BlockPredicate.Builder m_17924_() {
         return new BlockPredicate.Builder();
      }

      public BlockPredicate.Builder m_146726_(Block... p_146727_) {
         this.f_17920_ = Optional.of(HolderSet.m_205806_(Block::m_204297_, p_146727_));
         return this;
      }

      public BlockPredicate.Builder m_146722_(Collection<Block> p_298036_) {
         this.f_17920_ = Optional.of(HolderSet.m_205803_(Block::m_204297_, p_298036_));
         return this;
      }

      public BlockPredicate.Builder m_204027_(TagKey<Block> p_204028_) {
         this.f_146721_ = Optional.of(p_204028_);
         return this;
      }

      public BlockPredicate.Builder m_146724_(CompoundTag p_146725_) {
         this.f_17922_ = Optional.of(new NbtPredicate(p_146725_));
         return this;
      }

      public BlockPredicate.Builder m_17929_(StatePropertiesPredicate.Builder p_299418_) {
         this.f_17921_ = p_299418_.m_67706_();
         return this;
      }

      public BlockPredicate m_17931_() {
         return new BlockPredicate(this.f_146721_, this.f_17920_, this.f_17921_, this.f_17922_);
      }
   }
}