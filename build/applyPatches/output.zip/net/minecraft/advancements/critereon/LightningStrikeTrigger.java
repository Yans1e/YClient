package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.storage.loot.LootContext;

public class LightningStrikeTrigger extends SimpleCriterionTrigger<LightningStrikeTrigger.TriggerInstance> {
   public LightningStrikeTrigger.TriggerInstance m_7214_(JsonObject p_286889_, Optional<ContextAwarePredicate> p_301355_, DeserializationContext p_286384_) {
      Optional<ContextAwarePredicate> optional = EntityPredicate.m_36614_(p_286889_, "lightning", p_286384_);
      Optional<ContextAwarePredicate> optional1 = EntityPredicate.m_36614_(p_286889_, "bystander", p_286384_);
      return new LightningStrikeTrigger.TriggerInstance(p_301355_, optional, optional1);
   }

   public void m_153391_(ServerPlayer p_153392_, LightningBolt p_153393_, List<Entity> p_153394_) {
      List<LootContext> list = p_153394_.stream().map((p_153390_) -> {
         return EntityPredicate.m_36616_(p_153392_, p_153390_);
      }).collect(Collectors.toList());
      LootContext lootcontext = EntityPredicate.m_36616_(p_153392_, p_153393_);
      this.m_66234_(p_153392_, (p_153402_) -> {
         return p_153402_.m_153418_(lootcontext, list);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final Optional<ContextAwarePredicate> f_153407_;
      private final Optional<ContextAwarePredicate> f_153408_;

      public TriggerInstance(Optional<ContextAwarePredicate> p_299191_, Optional<ContextAwarePredicate> p_297442_, Optional<ContextAwarePredicate> p_299715_) {
         super(p_299191_);
         this.f_153407_ = p_297442_;
         this.f_153408_ = p_299715_;
      }

      public static Criterion<LightningStrikeTrigger.TriggerInstance> m_293278_(Optional<EntityPredicate> p_301310_, Optional<EntityPredicate> p_299336_) {
         return CriteriaTriggers.f_145089_.m_292665_(new LightningStrikeTrigger.TriggerInstance(Optional.empty(), EntityPredicate.m_295302_(p_301310_), EntityPredicate.m_295302_(p_299336_)));
      }

      public boolean m_153418_(LootContext p_153419_, List<LootContext> p_153420_) {
         if (this.f_153407_.isPresent() && !this.f_153407_.get().m_285831_(p_153419_)) {
            return false;
         } else {
            return !this.f_153408_.isPresent() || !p_153420_.stream().noneMatch(this.f_153408_.get()::m_285831_);
         }
      }

      public JsonObject m_7683_() {
         JsonObject jsonobject = super.m_7683_();
         this.f_153407_.ifPresent((p_297794_) -> {
            jsonobject.add("lightning", p_297794_.m_286026_());
         });
         this.f_153408_.ifPresent((p_297949_) -> {
            jsonobject.add("bystander", p_297949_.m_286026_());
         });
         return jsonobject;
      }
   }
}