package com.mojang.realmsclient.gui;

import com.mojang.realmsclient.dto.RealmsServer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RealmsServerList implements Iterable<RealmsServer> {
   private final Minecraft f_238634_;
   private final Set<RealmsServer> f_238560_ = new HashSet<>();
   private List<RealmsServer> f_238698_ = List.of();

   public RealmsServerList(Minecraft p_239233_) {
      this.f_238634_ = p_239233_;
   }

   public void m_239868_(List<RealmsServer> p_239869_) {
      List<RealmsServer> list = new ArrayList<>(p_239869_);
      list.sort(new RealmsServer.McoServerComparator(this.f_238634_.m_91094_().m_92546_()));
      boolean flag = list.removeAll(this.f_238560_);
      if (!flag) {
         this.f_238560_.clear();
      }

      this.f_238698_ = list;
   }

   public void m_240076_(RealmsServer p_240077_) {
      this.f_238698_.remove(p_240077_);
      this.f_238560_.add(p_240077_);
   }

   public Iterator<RealmsServer> iterator() {
      return this.f_238698_.iterator();
   }

   public boolean m_294497_() {
      return this.f_238698_.isEmpty();
   }
}