package com.mojang.realmsclient.gui.screens;

import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Either;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.WorldTemplate;
import com.mojang.realmsclient.dto.WorldTemplatePaginatedList;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.util.RealmsTextureManager;
import com.mojang.realmsclient.util.TextRenderingUtils;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsObjectSelectionList;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class RealmsSelectWorldTemplateScreen extends RealmsScreen {
   static final Logger f_89605_ = LogUtils.getLogger();
   static final ResourceLocation f_290336_ = new ResourceLocation("widget/slot_frame");
   private static final Component f_291505_ = Component.m_237115_("mco.template.button.select");
   private static final Component f_291283_ = Component.m_237115_("mco.template.button.trailer");
   private static final Component f_291853_ = Component.m_237115_("mco.template.button.publisher");
   private static final int f_291838_ = 100;
   private static final int f_290911_ = 10;
   private final HeaderAndFooterLayout f_291318_ = new HeaderAndFooterLayout(this);
   final Consumer<WorldTemplate> f_167479_;
   RealmsSelectWorldTemplateScreen.WorldTemplateObjectSelectionList f_89612_;
   private final RealmsServer.WorldType f_89598_;
   private Button f_89615_;
   private Button f_89616_;
   private Button f_89617_;
   @Nullable
   WorldTemplate f_89613_ = null;
   @Nullable
   String f_89597_;
   @Nullable
   private Component[] f_89600_;
   @Nullable
   List<TextRenderingUtils.Line> f_89604_;

   public RealmsSelectWorldTemplateScreen(Component p_167481_, Consumer<WorldTemplate> p_167482_, RealmsServer.WorldType p_167483_) {
      this(p_167481_, p_167482_, p_167483_, (WorldTemplatePaginatedList)null);
   }

   public RealmsSelectWorldTemplateScreen(Component p_167485_, Consumer<WorldTemplate> p_167486_, RealmsServer.WorldType p_167487_, @Nullable WorldTemplatePaginatedList p_167488_) {
      super(p_167485_);
      this.f_167479_ = p_167486_;
      this.f_89598_ = p_167487_;
      if (p_167488_ == null) {
         this.f_89612_ = new RealmsSelectWorldTemplateScreen.WorldTemplateObjectSelectionList();
         this.m_89653_(new WorldTemplatePaginatedList(10));
      } else {
         this.f_89612_ = new RealmsSelectWorldTemplateScreen.WorldTemplateObjectSelectionList(Lists.newArrayList(p_167488_.f_87753_));
         this.m_89653_(p_167488_);
      }

   }

   public void m_89682_(Component... p_89683_) {
      this.f_89600_ = p_89683_;
   }

   public void m_7856_() {
      this.f_291318_.m_269471_(new StringWidget(this.f_96539_, this.f_96547_));
      this.f_89612_ = new RealmsSelectWorldTemplateScreen.WorldTemplateObjectSelectionList(this.f_89612_.m_89818_());
      this.m_142416_(this.f_89612_);
      LinearLayout linearlayout = this.f_291318_.m_269281_(LinearLayout.m_295847_().m_294554_(10));
      linearlayout.m_294823_().m_264356_();
      this.f_89616_ = linearlayout.m_264406_(Button.m_253074_(f_291283_, (p_89701_) -> {
         this.m_89738_();
      }).m_252780_(100).m_253136_());
      this.f_89615_ = linearlayout.m_264406_(Button.m_253074_(f_291505_, (p_89696_) -> {
         this.m_89736_();
      }).m_252780_(100).m_253136_());
      linearlayout.m_264406_(Button.m_253074_(CommonComponents.f_130656_, (p_89691_) -> {
         this.m_7379_();
      }).m_252780_(100).m_253136_());
      this.f_89617_ = linearlayout.m_264406_(Button.m_253074_(f_291853_, (p_89679_) -> {
         this.m_89739_();
      }).m_252780_(100).m_253136_());
      this.m_89718_();
      this.f_291318_.m_264134_((p_296088_) -> {
         AbstractWidget abstractwidget = this.m_142416_(p_296088_);
      });
      this.m_267719_();
   }

   protected void m_267719_() {
      this.f_89612_.m_93437_(this.f_96543_, this.f_96544_, this.m_294786_(), this.f_96544_ - this.f_291318_.m_269040_());
      this.f_291318_.m_264036_();
   }

   public Component m_142562_() {
      List<Component> list = Lists.newArrayListWithCapacity(2);
      list.add(this.f_96539_);
      if (this.f_89600_ != null) {
         list.addAll(Arrays.asList(this.f_89600_));
      }

      return CommonComponents.m_178391_(list);
   }

   void m_89718_() {
      this.f_89617_.f_93624_ = this.f_89613_ != null && !this.f_89613_.f_87730_.isEmpty();
      this.f_89616_.f_93624_ = this.f_89613_ != null && !this.f_89613_.f_87732_.isEmpty();
      this.f_89615_.f_93623_ = this.f_89613_ != null;
   }

   public void m_7379_() {
      this.f_167479_.accept((WorldTemplate)null);
   }

   private void m_89736_() {
      if (this.f_89613_ != null) {
         this.f_167479_.accept(this.f_89613_);
      }

   }

   private void m_89738_() {
      if (this.f_89613_ != null && !this.f_89613_.f_87732_.isBlank()) {
         this.f_96541_.m_91152_(new ConfirmLinkScreen((p_296089_) -> {
            if (p_296089_) {
               Util.m_137581_().m_137646_(this.f_89613_.f_87732_);
            }

            this.f_96541_.m_91152_(this);
         }, this.f_89613_.f_87732_, true));
      }

   }

   private void m_89739_() {
      if (this.f_89613_ != null && !this.f_89613_.f_87730_.isBlank()) {
         ConfirmLinkScreen.m_274480_(this.f_89613_.f_87730_, this, true);
      }

   }

   private void m_89653_(final WorldTemplatePaginatedList p_89654_) {
      (new Thread("realms-template-fetcher") {
         public void run() {
            WorldTemplatePaginatedList worldtemplatepaginatedlist = p_89654_;

            RealmsClient realmsclient = RealmsClient.m_87169_();
            while (worldtemplatepaginatedlist != null) {
               Either<WorldTemplatePaginatedList, Exception> either = RealmsSelectWorldTemplateScreen.this.m_89655_(worldtemplatepaginatedlist, realmsclient);
               worldtemplatepaginatedlist = RealmsSelectWorldTemplateScreen.this.f_96541_.m_18691_(() -> {
               if (either.right().isPresent()) {
                  RealmsSelectWorldTemplateScreen.f_89605_.error("Couldn't fetch templates", either.right().get());
                  if (RealmsSelectWorldTemplateScreen.this.f_89612_.m_89817_()) {
                     RealmsSelectWorldTemplateScreen.this.f_89604_ = TextRenderingUtils.m_90256_(I18n.m_118938_("mco.template.select.failure"));
                  }

                  return null;
               } else {
                  WorldTemplatePaginatedList worldtemplatepaginatedlist1 = either.left().get();

                  for(WorldTemplate worldtemplate : worldtemplatepaginatedlist1.f_87753_) {
                     RealmsSelectWorldTemplateScreen.this.f_89612_.m_89804_(worldtemplate);
                  }

                  if (worldtemplatepaginatedlist1.f_87753_.isEmpty()) {
                     if (RealmsSelectWorldTemplateScreen.this.f_89612_.m_89817_()) {
                        String s = I18n.m_118938_("mco.template.select.none", "%link");
                        TextRenderingUtils.LineSegment textrenderingutils$linesegment = TextRenderingUtils.LineSegment.m_90281_(I18n.m_118938_("mco.template.select.none.linkTitle"), "https://aka.ms/MinecraftRealmsContentCreator");
                        RealmsSelectWorldTemplateScreen.this.f_89604_ = TextRenderingUtils.m_90256_(s, textrenderingutils$linesegment);
                     }

                     return null;
                  } else {
                     return worldtemplatepaginatedlist1;
                  }
               }
            }).join();
            }

         }
      }).start();
   }

   Either<WorldTemplatePaginatedList, Exception> m_89655_(WorldTemplatePaginatedList p_89656_, RealmsClient p_89657_) {
      try {
         return Either.left(p_89657_.m_87170_(p_89656_.f_87754_ + 1, p_89656_.f_87755_, this.f_89598_));
      } catch (RealmsServiceException realmsserviceexception) {
         return Either.right(realmsserviceexception);
      }
   }

   public void m_88315_(GuiGraphics p_282162_, int p_89640_, int p_89641_, float p_89642_) {
      super.m_88315_(p_282162_, p_89640_, p_89641_, p_89642_);
      this.f_89597_ = null;
      if (this.f_89604_ != null) {
         this.m_280418_(p_282162_, p_89640_, p_89641_, this.f_89604_);
      }

      if (this.f_89600_ != null) {
         for(int i = 0; i < this.f_89600_.length; ++i) {
            Component component = this.f_89600_[i];
            p_282162_.m_280653_(this.f_96547_, component, this.f_96543_ / 2, m_120774_(-1 + i), -6250336);
         }
      }

   }

   private void m_280418_(GuiGraphics p_282398_, int p_282163_, int p_282021_, List<TextRenderingUtils.Line> p_282203_) {
      for(int i = 0; i < p_282203_.size(); ++i) {
         TextRenderingUtils.Line textrenderingutils$line = p_282203_.get(i);
         int j = m_120774_(4 + i);
         int k = textrenderingutils$line.f_90262_.stream().mapToInt((p_280748_) -> {
            return this.f_96547_.m_92895_(p_280748_.m_90278_());
         }).sum();
         int l = this.f_96543_ / 2 - k / 2;

         for(TextRenderingUtils.LineSegment textrenderingutils$linesegment : textrenderingutils$line.f_90262_) {
            int i1 = textrenderingutils$linesegment.m_90284_() ? 3368635 : -1;
            int j1 = p_282398_.m_280488_(this.f_96547_, textrenderingutils$linesegment.m_90278_(), l, j, i1);
            if (textrenderingutils$linesegment.m_90284_() && p_282163_ > l && p_282163_ < j1 && p_282021_ > j - 3 && p_282021_ < j + 8) {
               this.m_257404_(Component.m_237113_(textrenderingutils$linesegment.m_90285_()));
               this.f_89597_ = textrenderingutils$linesegment.m_90285_();
            }

            l = j1;
         }
      }

   }

   int m_294786_() {
      return this.f_89600_ != null ? m_120774_(1) : 36;
   }

   @OnlyIn(Dist.CLIENT)
   class Entry extends ObjectSelectionList.Entry<RealmsSelectWorldTemplateScreen.Entry> {
      private static final WidgetSprites f_291729_ = new WidgetSprites(new ResourceLocation("icon/link"), new ResourceLocation("icon/link_highlighted"));
      private static final WidgetSprites f_291679_ = new WidgetSprites(new ResourceLocation("icon/video_link"), new ResourceLocation("icon/video_link_highlighted"));
      private static final Component f_291061_ = Component.m_237115_("mco.template.info.tooltip");
      private static final Component f_291117_ = Component.m_237115_("mco.template.trailer.tooltip");
      public final WorldTemplate f_89750_;
      private long f_290925_;
      @Nullable
      private ImageButton f_290742_;
      @Nullable
      private ImageButton f_291756_;

      public Entry(WorldTemplate p_89753_) {
         this.f_89750_ = p_89753_;
         if (!p_89753_.f_87730_.isBlank()) {
            this.f_290742_ = new ImageButton(15, 15, f_291729_, ConfirmLinkScreen.m_274609_(p_89753_.f_87730_, RealmsSelectWorldTemplateScreen.this, true), f_291061_);
            this.f_290742_.m_257544_(Tooltip.m_257550_(f_291061_));
         }

         if (!p_89753_.f_87732_.isBlank()) {
            this.f_291756_ = new ImageButton(15, 15, f_291679_, ConfirmLinkScreen.m_274609_(p_89753_.f_87732_, RealmsSelectWorldTemplateScreen.this, true), f_291117_);
            this.f_291756_.m_257544_(Tooltip.m_257550_(f_291117_));
         }

      }

      public boolean m_6375_(double p_299958_, double p_298696_, int p_299792_) {
         if (p_299792_ == 0) {
            RealmsSelectWorldTemplateScreen.this.f_89613_ = this.f_89750_;
            RealmsSelectWorldTemplateScreen.this.m_89718_();
            if (Util.m_137550_() - this.f_290925_ < 250L && this.m_93696_()) {
               RealmsSelectWorldTemplateScreen.this.f_167479_.accept(this.f_89750_);
            }

            this.f_290925_ = Util.m_137550_();
            if (this.f_290742_ != null) {
               this.f_290742_.m_6375_(p_299958_, p_298696_, p_299792_);
            }

            if (this.f_291756_ != null) {
               this.f_291756_.m_6375_(p_299958_, p_298696_, p_299792_);
            }

            return true;
         } else {
            return super.m_6375_(p_299958_, p_298696_, p_299792_);
         }
      }

      public void m_6311_(GuiGraphics p_281796_, int p_282160_, int p_281759_, int p_282961_, int p_281497_, int p_282427_, int p_283550_, int p_282955_, boolean p_282866_, float p_281452_) {
         p_281796_.m_280163_(RealmsTextureManager.m_269474_(this.f_89750_.f_87726_, this.f_89750_.f_87731_), p_282961_ + 1, p_281759_ + 1 + 1, 0.0F, 0.0F, 38, 38, 38, 38);
         p_281796_.m_292816_(RealmsSelectWorldTemplateScreen.f_290336_, p_282961_, p_281759_ + 1, 40, 40);
         int i = 5;
         int j = RealmsSelectWorldTemplateScreen.this.f_96547_.m_92895_(this.f_89750_.f_87728_);
         if (this.f_290742_ != null) {
            this.f_290742_.m_264152_(p_282961_ + p_281497_ - j - this.f_290742_.m_5711_() - 10, p_281759_);
            this.f_290742_.m_88315_(p_281796_, p_283550_, p_282955_, p_281452_);
         }

         if (this.f_291756_ != null) {
            this.f_291756_.m_264152_(p_282961_ + p_281497_ - j - this.f_291756_.m_5711_() * 2 - 15, p_281759_);
            this.f_291756_.m_88315_(p_281796_, p_283550_, p_282955_, p_281452_);
         }

         int k = p_282961_ + 45 + 20;
         int l = p_281759_ + 5;
         p_281796_.m_280056_(RealmsSelectWorldTemplateScreen.this.f_96547_, this.f_89750_.f_87727_, k, l, -1, false);
         p_281796_.m_280056_(RealmsSelectWorldTemplateScreen.this.f_96547_, this.f_89750_.f_87728_, p_282961_ + p_281497_ - j - 5, l, 7105644, false);
         p_281796_.m_280056_(RealmsSelectWorldTemplateScreen.this.f_96547_, this.f_89750_.f_87729_, k, l + 9 + 5, -6250336, false);
         if (!this.f_89750_.f_87733_.isBlank()) {
            p_281796_.m_280056_(RealmsSelectWorldTemplateScreen.this.f_96547_, this.f_89750_.f_87733_, k, p_281759_ + p_282427_ - 9 / 2 - 5, 5000268, false);
         }

      }

      public Component m_142172_() {
         Component component = CommonComponents.m_178396_(Component.m_237113_(this.f_89750_.f_87727_), Component.m_237110_("mco.template.select.narrate.authors", this.f_89750_.f_87729_), Component.m_237113_(this.f_89750_.f_87733_), Component.m_237110_("mco.template.select.narrate.version", this.f_89750_.f_87728_));
         return Component.m_237110_("narrator.select", component);
      }
   }

   @OnlyIn(Dist.CLIENT)
   class WorldTemplateObjectSelectionList extends RealmsObjectSelectionList<RealmsSelectWorldTemplateScreen.Entry> {
      public WorldTemplateObjectSelectionList() {
         this(Collections.emptyList());
      }

      public WorldTemplateObjectSelectionList(Iterable<WorldTemplate> p_89795_) {
         super(RealmsSelectWorldTemplateScreen.this.f_96543_, RealmsSelectWorldTemplateScreen.this.f_96544_, RealmsSelectWorldTemplateScreen.this.m_294786_(), RealmsSelectWorldTemplateScreen.this.f_96544_ - 36, 46);
         p_89795_.forEach(this::m_89804_);
      }

      public void m_89804_(WorldTemplate p_89805_) {
         this.m_7085_(RealmsSelectWorldTemplateScreen.this.new Entry(p_89805_));
      }

      public boolean m_6375_(double p_89797_, double p_89798_, int p_89799_) {
         if (RealmsSelectWorldTemplateScreen.this.f_89597_ != null) {
            ConfirmLinkScreen.m_274480_(RealmsSelectWorldTemplateScreen.this.f_89597_, RealmsSelectWorldTemplateScreen.this, true);
            return true;
         } else {
            return super.m_6375_(p_89797_, p_89798_, p_89799_);
         }
      }

      public void m_6987_(@Nullable RealmsSelectWorldTemplateScreen.Entry p_89807_) {
         super.m_6987_(p_89807_);
         RealmsSelectWorldTemplateScreen.this.f_89613_ = p_89807_ == null ? null : p_89807_.f_89750_;
         RealmsSelectWorldTemplateScreen.this.m_89718_();
      }

      public int m_5775_() {
         return this.m_5773_() * 46;
      }

      public int m_5759_() {
         return 300;
      }

      public boolean m_89817_() {
         return this.m_5773_() == 0;
      }

      public List<WorldTemplate> m_89818_() {
         return this.m_6702_().stream().map((p_89814_) -> {
            return p_89814_.f_89750_;
         }).collect(Collectors.toList());
      }
   }
}
