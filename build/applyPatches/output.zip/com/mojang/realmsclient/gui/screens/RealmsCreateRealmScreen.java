package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.util.task.WorldCreationTask;
import net.minecraft.Util;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.CommonLayouts;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RealmsCreateRealmScreen extends RealmsScreen {
   private static final Component f_88564_ = Component.m_237115_("mco.configure.world.name");
   private static final Component f_88565_ = Component.m_237115_("mco.configure.world.description");
   private static final int f_291883_ = 10;
   private static final int f_291606_ = 210;
   private final RealmsServer f_88566_;
   private final RealmsMainScreen f_88567_;
   private final HeaderAndFooterLayout f_290596_ = new HeaderAndFooterLayout(this);
   private EditBox f_88568_;
   private EditBox f_88569_;

   public RealmsCreateRealmScreen(RealmsServer p_88574_, RealmsMainScreen p_88575_) {
      super(Component.m_237115_("mco.selectServer.create"));
      this.f_88566_ = p_88574_;
      this.f_88567_ = p_88575_;
   }

   public void m_7856_() {
      this.f_290596_.m_269471_(new StringWidget(this.f_96539_, this.f_96547_));
      LinearLayout linearlayout = this.f_290596_.m_268999_(LinearLayout.m_293633_()).m_294554_(10);
      Button button = Button.m_253074_(Component.m_237115_("mco.create.world"), (p_88592_) -> {
         this.m_88595_();
      }).m_253136_();
      button.f_93623_ = false;
      this.f_88568_ = new EditBox(this.f_96547_, 210, 20, Component.m_237115_("mco.configure.world.name"));
      this.f_88568_.m_94151_((p_296055_) -> {
         button.f_93623_ = !Util.m_288217_(p_296055_);
      });
      this.f_88569_ = new EditBox(this.f_96547_, 210, 20, Component.m_237115_("mco.configure.world.description"));
      linearlayout.m_264406_(CommonLayouts.m_294456_(this.f_96547_, this.f_88568_, f_88564_));
      linearlayout.m_264406_(CommonLayouts.m_294456_(this.f_96547_, this.f_88569_, f_88565_));
      LinearLayout linearlayout1 = this.f_290596_.m_269281_(LinearLayout.m_295847_().m_294554_(10));
      linearlayout1.m_264406_(button);
      linearlayout1.m_264406_(Button.m_253074_(CommonComponents.f_130656_, (p_296056_) -> {
         this.m_7379_();
      }).m_253136_());
      this.f_290596_.m_264134_((p_296058_) -> {
         AbstractWidget abstractwidget = this.m_142416_(p_296058_);
      });
      this.m_267719_();
      this.m_264313_(this.f_88568_);
   }

   protected void m_267719_() {
      this.f_290596_.m_264036_();
   }

   private void m_88595_() {
      RealmsResetWorldScreen realmsresetworldscreen = RealmsResetWorldScreen.m_294089_(this.f_88567_, this.f_88566_, () -> {
         this.f_96541_.execute(() -> {
            this.f_88567_.m_294350_();
            this.f_96541_.m_91152_(this.f_88567_);
         });
      });
      this.f_96541_.m_91152_(new RealmsLongRunningMcoTaskScreen(this.f_88567_, new WorldCreationTask(this.f_88566_.f_87473_, this.f_88568_.m_94155_(), this.f_88569_.m_94155_(), realmsresetworldscreen)));
   }

   public void m_7379_() {
      this.f_96541_.m_91152_(this.f_88567_);
   }
}