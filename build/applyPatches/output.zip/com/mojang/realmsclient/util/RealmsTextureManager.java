package com.mojang.realmsclient.util;

import com.google.common.collect.Maps;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Base64;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class RealmsTextureManager {
   private static final Map<String, RealmsTextureManager.RealmsTexture> f_90178_ = Maps.newHashMap();
   private static final Logger f_90181_ = LogUtils.getLogger();
   private static final ResourceLocation f_90182_ = new ResourceLocation("textures/gui/presets/isles.png");

   public static ResourceLocation m_269474_(String p_270945_, @Nullable String p_270612_) {
      return p_270612_ == null ? f_90182_ : m_90196_(p_270945_, p_270612_);
   }

   private static ResourceLocation m_90196_(String p_90197_, String p_90198_) {
      RealmsTextureManager.RealmsTexture realmstexturemanager$realmstexture = f_90178_.get(p_90197_);
      if (realmstexturemanager$realmstexture != null && realmstexturemanager$realmstexture.f_90205_().equals(p_90198_)) {
         return realmstexturemanager$realmstexture.f_90206_;
      } else {
         NativeImage nativeimage = m_269309_(p_90198_);
         if (nativeimage == null) {
            ResourceLocation resourcelocation1 = MissingTextureAtlasSprite.m_118071_();
            f_90178_.put(p_90197_, new RealmsTextureManager.RealmsTexture(p_90198_, resourcelocation1));
            return resourcelocation1;
         } else {
            ResourceLocation resourcelocation = new ResourceLocation("realms", "dynamic/" + p_90197_);
            Minecraft.m_91087_().m_91097_().m_118495_(resourcelocation, new DynamicTexture(nativeimage));
            f_90178_.put(p_90197_, new RealmsTextureManager.RealmsTexture(p_90198_, resourcelocation));
            return resourcelocation;
         }
      }
   }

   @Nullable
   private static NativeImage m_269309_(String p_270725_) {
      byte[] abyte = Base64.getDecoder().decode(p_270725_);
      ByteBuffer bytebuffer = MemoryUtil.memAlloc(abyte.length);

      try {
         return NativeImage.m_85062_(bytebuffer.put(abyte).flip());
      } catch (IOException ioexception) {
         f_90181_.warn("Failed to load world image: {}", p_270725_, ioexception);
      } finally {
         MemoryUtil.memFree(bytebuffer);
      }

      return null;
   }

   @OnlyIn(Dist.CLIENT)
   public static record RealmsTexture(String f_90205_, ResourceLocation f_90206_) {
   }
}