package com.mojang.blaze3d.shaders;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface Shader {
   int m_108943_();

   void m_108957_();

   Program m_108962_();

   Program m_108964_();

   void m_142662_();
}